# LinnStrument Ableton Remote Script v1.26

Based on LinnStrument v1.25.

Momentary Copy Mode:
- Session Mode column 1 Pad 2 is now momentary, like Delete Mode.
- Hold Pad 2 to keep Copy Mode active.
- Release Pad 2 to cancel/end Copy Mode.
- After a successful copy, Copy Mode stays active while Pad 2 remains held.
- The source resets automatically, allowing multiple copy operations in sequence.

Retained:
- Unified Copy Mode: first selected object decides Clip or Scene.
- Copy Clip only into empty target clip slots.
- Copy Scene only into completely empty target scenes.
- MIDI/Audio mismatch aborts the current copy operation.
- Tempo controls from v1.24.
