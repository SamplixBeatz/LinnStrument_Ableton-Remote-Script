# LinnStrument Ableton Remote Script v1.35

Based on v1.34.

New:
- Session Mode dynamic control column:
  - LinnStrument 128: column 15
  - LinnStrument 200: corresponding dynamic control column
- Pad 5 in that column:
  - Without Shift: Toggle Mixer Mode, unchanged
  - With Shift: Stop all clips

Retained:
- Stable v1.34 Session Mode startup.
- All v1.34 functionality.
- No Drum Mode, Note AV, Soft Mute/Solo/Stop, or Solo/Cue experiments included.
