# LinnStrument Ableton Remote Script v1.29

Based on v1.28.

Changes:
- Soft Stop removed.
- Shift + Track Control Mute (Stop Track Clips) restored to the previous immediate stop behavior.

Retained:
- Soft Mute from v1.27.
- Soft Solo from v1.28.
- Momentary Unified Copy Mode.
- Tempo controls from v1.24.
- LinnStrument 128/200 auto-detect.
