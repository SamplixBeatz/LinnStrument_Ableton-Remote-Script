# LinnStrument_200_Session_View v1.0.1

Session-View Remote Script based on stable LinnStrument v1.35.

Fixed hardware model:
- LinnStrument 200

Important:
- Folder name is changed for Ableton's Control Surface list.
- Internal Python class/import names are kept compatible with the original v1.35 script.

Install:
Copy the complete folder `LinnStrument_200_Session_View` into Ableton's MIDI Remote Scripts folder and restart Live.
