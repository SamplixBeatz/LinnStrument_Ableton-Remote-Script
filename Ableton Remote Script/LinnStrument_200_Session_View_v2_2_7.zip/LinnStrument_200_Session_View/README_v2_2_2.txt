LinnStrument 200 Session View v2.2.2

Functionality is unchanged from the v2.2.0 Session View release.
Version aligned with the complete project release.
