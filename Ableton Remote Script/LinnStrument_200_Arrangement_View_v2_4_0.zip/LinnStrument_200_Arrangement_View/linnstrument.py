from __future__ import absolute_import, print_function, unicode_literals

import socket
import struct

import Live

try:
    from _Framework.ControlSurface import ControlSurface
except ImportError:
    from ableton.v2.control_surface import ControlSurface

from .colors import ColorMap, TRACK_CLIP_COLORS, LS_RGB, LSColor
from .constants import (
    SESSION_RECORD_CC, SESSION_MODE_CC, USER_MODE_NRPN,
    NOTE_MODE_FUNCTION_CCS,
    NOTE_MODE_CC_UNDO, NOTE_MODE_CC_RECORD_CLIP, NOTE_MODE_CC_CAPTURE_MIDI,
    NOTE_MODE_CC_DELETE_ACTIVE_CLIP, NOTE_MODE_CC_METRONOME, NOTE_MODE_CC_STOP_SELECTED_TRACK, NOTE_MODE_CC_CAPTURE_MIDI,
    NOTE_MODE_CC_SESSION_RECORD, NOTE_MODE_CC_ENTER_SESSION,
    PLAYABLE_COLUMN_FIRST, TRACK_COLUMNS, FUNCTION_COLUMN, FIXED_LENGTH_COLUMN, SCENE_COLUMN,
    CLIP_ROW_FIRST, CLIP_ROW_LAST,
    ARM_ROW, SOLO_ROW, MUTE_ROW, USER_MODE_CONTROL_COLUMN,
    UNDO_ROW, REDO_ROW, DUPLICATE_CLIP_ROW, DUPLICATE_SCENE_ROW,
    CAPTURE_SCENE_ROW, PLAY_STOP_ROW, DELETE_MODE_ROW, SESSION_RECORD_ROW,
    TRACK_BANK_RIGHT_ROW, TRACK_BANK_LEFT_ROW, NOTE_MODE_ROW,
    METRONOME_ROW, METRONOME_ROW_FUNCTION, SCENE_BANK_UP_ROW, SCENE_BANK_DOWN_ROW, SHIFT_ROW, TRACK_CONTROL_MODE_ROW,
    UPDATE_DISPLAY_REFRESH_INTERVAL, BLINK_ON_TICKS, BLINK_OFF_TICKS,
    SCENE_BANK_STEP, TRACK_BANK_STEP,
    FIXED_LENGTH_1_BAR_ROW, FIXED_LENGTH_2_BARS_ROW, FIXED_LENGTH_4_BARS_ROW,
    FIXED_LENGTH_8_BARS_ROW,
    LAUNCH_QUANT_1_BAR_ROW, LAUNCH_QUANT_1_4_ROW, LAUNCH_QUANT_1_8_ROW,
    LAUNCH_QUANT_1_16_ROW, LAUNCH_QUANT_1_32_ROW, MIXER_MODE_ROW, TC_ARM_ROW, TC_SOLO_ROW, TC_MUTE_ROW
)


class LinnStrument(ControlSurface):
    def __init__(self, c_instance):
        super(LinnStrument, self).__init__(c_instance)
        self._session_mode = False
        # v2.2.8 Active-track mixer block for LinnStrument 200.
        # Physical columns N/O/P/Q = Sends A/B/C/D, S = Pan, T = Volume.
        # All faders are protected by Arrangement Shift (Y8).
        self._arrangement_active_faders = {}
        self._arrangement_last_selected_track_object = None
        self._arrangement_pan_led_states = {}
        self._arrangement_mode = False
        self._controller_columns = 25
        self._track_columns_dynamic = 22
        self._fixed_length_column_dynamic = 24
        self._scene_column_dynamic = 25
        self._mixer_mode = False
        self._delete_mode = False
        self._copy_mode = False
        self._copy_source = None
        self._copy_source_type = None
        self._copy_scene_mode = False
        self._copy_scene_source = None
        self._copy_scene_mode = False
        self._copy_scene_source = None
        self._shift = False
        self._fixed_length_bars = 0
        self._fixed_length_slot = None
        self._fixed_length_start_beats = None
        self._fixed_length_target_beats = None
        self._fixed_length_seen_recording = False
        self._launch_quant_row = LAUNCH_QUANT_1_BAR_ROW
        self._track_offset = 0
        self._scene_offset = 0
        self._allow_control_exit = False
        self._update_counter = 0

        # v3.8 fastblink
        self._blink_counter = 0
        self._blink_on = True

        self._last_session_record_cc_value = None
        self._note_mode_cc_states = {}
        self._last_pressed_track_index = None
        self._last_pressed_scene_index = None
        self._copy_mode = False
        self._copy_source = None
        self._play_stop_protected = False
        self._note_return_mode = "session"
        self._arrangement_held_arrows = set()
        self._arrangement_arrow_repeat_active = False
        self._arrangement_udp_host = "127.0.0.1"
        self._arrangement_udp_port = 9001
        self._arrangement_udp_socket = None
        self._scrub_udp_port = 9002
        self._scrub_pad_held = None
        self._scrub_y_value = 0
        self._scrub_repeat_active = False
        # v2.2.4 H8/J8 vertical active-track zoom hold controls.
        self._track_zoom_held = None
        self._track_zoom_repeat_active = False
        self._arrangement_mode = False
        self.log_message("LinnStrument 200 Arrangement View v2.4.0 loaded")
        self.show_message("LinnStrument 200 Arrangement View v2.4.0 loaded")
        self._clear_session_highlight()

        # v1.34:
        # Start in Session Mode again, but use the explicit enter_session_mode()
        # path that proved stable in the diagnostic builds.
        self.enter_arrangement_mode()

    def _draw_note_mode_function_leds(self):
        # v3.10.66: Note Mode function column layout.
        if self._session_mode:
            return
        try:
            self._set_pad_color(FUNCTION_COLUMN, 7, ColorMap.UNDO)              # Pad 1 Undo
            self._set_pad_color(FUNCTION_COLUMN, 6, ColorMap.MAGENTA)           # Pad 2 Fire Record Clip
            self._set_pad_color(FUNCTION_COLUMN, 5, ColorMap.CAPTURE_SCENE)     # Pad 3 MIDI Capture
            self._set_pad_color(FUNCTION_COLUMN, 4, ColorMap.DELETE_MODE_ON)    # Pad 4 Delete active clip
            self._set_pad_color(FUNCTION_COLUMN, 3, self._metronome_button_color()) # Pad 5 Metronome
            self._set_pad_color(FUNCTION_COLUMN, 2, self._play_stop_button_color() if self._arrangement_view_is_visible() else ColorMap.PLAY_ON) # Pad 6 Stop Clip / Play-Stop
            self._set_pad_color(FUNCTION_COLUMN, 1, self._session_record_button_color()) # Pad 7 Session/Arrangement Record
            self._set_pad_color(FUNCTION_COLUMN, 0, ColorMap.WHITE)             # Pad 8 Session Mode
        except Exception as e:
            try:
                self.log_message("Note Mode LED draw failed: %s" % e)
            except Exception:
                pass




    def update_display(self):
        try:
            super(LinnStrument, self).update_display()
        except Exception:
            pass

        if bool(getattr(self, "_arrangement_mode", False)):
            try:
                selected_track = self.song().view.selected_track
                if selected_track is not getattr(
                    self, "_arrangement_last_selected_track_object", None
                ):
                    self._arrangement_last_selected_track_object = selected_track
                    self._arrangement_pan_led_states = {}
                    self._arrangement_clear_active_track_faders()
                    self._draw_arrangement_active_track_mixer()
            except Exception as e:
                try:
                    self.log_message(
                        "Arrangement selected-track display update failed: %s" % e
                    )
                except Exception:
                    pass
            return

        self._update_fixed_length_recording()

        if self._session_mode:
            if self._mixer_mode:
                self._mixer_gap_glide_tick()
            self._update_counter += 1
            if self._update_counter >= UPDATE_DISPLAY_REFRESH_INTERVAL:
                self._update_counter = 0
                self._advance_blink()
                self._draw_session_leds()
        else:
            self._update_counter += 1
            if self._update_counter >= UPDATE_DISPLAY_REFRESH_INTERVAL:
                self._update_counter = 0
                self._advance_blink()
                self._draw_note_mode_function_leds()

    def _advance_blink(self):
        self._blink_counter += 1
        limit = BLINK_ON_TICKS if self._blink_on else BLINK_OFF_TICKS
        if self._blink_counter >= limit:
            self._blink_counter = 0
            self._blink_on = not self._blink_on

    def _arrangement_view_refactor_marker(self):
        return "Arrangement_View v1.0.3-refactor2b"


    def build_midi_map(self, midi_map_handle):
        super(LinnStrument, self).build_midi_map(midi_map_handle)
        script_handle = self._c_instance.handle()

        # Note Mode left-split CC fader buttons.
        # Ableton channels are zero-based: channel 0 = MIDI channel 1.
        for cc in NOTE_MODE_FUNCTION_CCS:
            Live.MidiMap.forward_midi_cc(script_handle, midi_map_handle, 0, cc)

        for channel in range(16):
            # CC64/CC65 are no longer used for mode switching in v3.10.0.
            for cc in NOTE_MODE_FUNCTION_CCS:
                Live.MidiMap.forward_midi_cc(script_handle, midi_map_handle, channel, cc)

        for channel in range(8):
            for note in range(26):
                Live.MidiMap.forward_midi_note(script_handle, midi_map_handle, channel, note)

        # v3.10.50: forward LinnStrument User Firmware Mode Y-axis CCs.
        # Measured mapping: column 1 = CC65 ... column 16 = CC80.
        # Channel 1-8 = row bottom-to-top.
        for channel in range(8):
            for cc in range(65, 90):
                Live.MidiMap.forward_midi_cc(script_handle, midi_map_handle, channel, cc)

        self.log_message("LinnStrument LinnStrument_200 Arrangement_View v1.0.3-refactor2b MIDI map built")

    def disconnect(self):
        try:
            if getattr(self, "_arrangement_udp_socket", None) is not None:
                self._arrangement_udp_socket.close()
                self._arrangement_udp_socket = None
        except Exception:
            pass

        # v3.10.40: keep disconnect minimal.
        # Do not force Note Mode during project changes.
        try:
            self._clear_session_highlight()
        except Exception:
            pass

        try:
            super(LinnStrument, self).disconnect()
        except Exception:
            pass


    def receive_midi(self, midi_bytes):
        if not midi_bytes or len(midi_bytes) < 3:
            return

        status, data1, data2 = midi_bytes[0], midi_bytes[1], midi_bytes[2]
        message_type = status & 0xF0

        if message_type == 0xB0:
            channel = status & 0x0F
            cc = data1
            value = data2

            # N4/P4 Y-scrub. Physical row 4 = MIDI channel 5.
            # v2.2.8 Active-track mixer Y fine control.
            # Physical columns and CCs:
            # N=14/CC78 Send A, O=15/CC79 Send B,
            # P=16/CC80 Send C, Q=17/CC81 Send D,
            # S=19/CC83 Pan, T=20/CC84 Volume.
            if bool(getattr(self, "_arrangement_mode", False)) and cc in (78, 79, 80, 81, 83, 84):
                physical_column = int(cc) - 64
                active = getattr(self, "_arrangement_active_faders", {})

                # Active Track Control remains Shift-protected on LinnStrument 200.
                # Keep the proven 128-style MIDI-channel fallback for the row,
                # but process Y only while Arrangement Shift is actually held.
                if bool(getattr(self, "_shift", False)) and self._arrangement_active_track_fader_kind(physical_column) is not None:
                    row = active.get(physical_column, channel)
                    self._arrangement_set_active_track_fader_from_y(
                        physical_column,
                        int(row),
                        int(value),
                    )
                return

            # LinnStrument 200 physical mapping:
            # logical N -> physical column 23 -> CC87
            # logical P -> physical column 25 -> CC89
            if bool(getattr(self, "_arrangement_mode", False)) and channel == 4 and cc in (87, 89):
                pad_name = "N4" if cc == 87 else "P4"
                self._scrub_debug("%s Y CC%d ch5 value=%d active=%s" % (
                    pad_name, int(cc), int(value), getattr(self, "_scrub_pad_held", None)))
                if getattr(self, "_scrub_pad_held", None) == pad_name:
                    self._scrub_y_value = int(value)
                    if not bool(getattr(self, "_scrub_repeat_active", False)):
                        self._scrub_repeat_active = True
                        self.schedule_message(1, self._scrub_tick)
                return

            # v3.10.49: Mixer fine control from LinnStrument User Firmware Mode Y.
            # Measured mapping: column 1 = CC65, column 2 = CC66, ... column 16 = CC80.
            # Channel 1-8 = row bottom-to-top.
            if self._session_mode and self._mixer_mode and 65 <= cc <= 89:
                column = cc - 64
                if PLAYABLE_COLUMN_FIRST <= column < PLAYABLE_COLUMN_FIRST + self._track_columns():
                    track_index = self._track_offset + (column - PLAYABLE_COLUMN_FIRST)
                    row = self._mixer_fine_active.get(track_index, channel)
                    self._set_track_volume_from_y(track_index, row, value)
                    return



            if data1 in NOTE_MODE_FUNCTION_CCS:
                self._handle_note_mode_function_cc(data1, data2)
                return

        if message_type == 0x90 or message_type == 0x80:
            row = status & 0x0F
            column = data1
            self._detect_controller_model_from_column(column)
            is_note_on = (message_type == 0x90 and data2 > 0)
            is_note_off = (message_type == 0x80) or (message_type == 0x90 and data2 == 0)

            if is_note_on:
                if column == USER_MODE_CONTROL_COLUMN:
                    if not self._allow_control_exit:
                        return
                    self.enter_note_mode()
                    return

                # arrangement-only note-on
                if bool(getattr(self, "_arrangement_mode", False)):
                    if self._handle_arrangement_pad(column, row):
                        return
                    return

                if self._session_mode:
                    if bool(getattr(self, "_arrangement_mode", False)):
                        # v1.70: In Arrangement Mode, ignore the Session Mode fixed-length/mixer
                        # column exit shortcut. On LinnStrument 200, self._fixed_length_column()
                        # shifts to column 24, causing pad 5 / column 24 to exit Arrangement Mode.
                        if self._handle_arrangement_pad(column, row):
                            return
                        return
                    self._handle_grid_press(column, row)
            # arrangement-only note-off
            elif is_note_off:
                if bool(getattr(self, "_arrangement_mode", False)):
                    if self._arrangement_shift_pad_for(column, row):
                        self._shift = False
                        self._arrangement_clear_active_track_faders()
                        self._draw_arrangement_mode_leds()
                        self.show_message("LinnStrument Arrangement: Shift OFF")
                        return
                    if self._handle_arrangement_pad_release(column, row):
                        return

                if self._session_mode and bool(getattr(self, "_arrangement_mode", False)):
                    if self._arrangement_shift_pad_for(column, row):
                        self._shift = False
                        self._arrangement_clear_active_track_faders()
                        self._draw_arrangement_mode_leds()
                        self.show_message("LinnStrument Arrangement: Shift OFF")
                        return
                    if self._handle_arrangement_pad_release(column, row):
                        return

                if self._session_mode and column == FUNCTION_COLUMN and row == DUPLICATE_CLIP_ROW:
                    self._end_copy_mode()
                    return

                if self._session_mode and self._mixer_mode:
                    # v3.10.52: keep row latch through short Note Off events while sliding
                    # across pad boundaries. Latches are cleared when leaving/toggling Mixer Mode.
                    pass

                # v3.10.4: momentary Shift release in Session Mode.
                # LinnStrument may send either Note On velocity 0 or real Note Off.
                if self._session_mode and column == self._scene_column() and row == SHIFT_ROW:
                    self._shift = False
                    if bool(getattr(self, "_arrangement_mode", False)):
                        self._draw_arrangement_mode_leds()
                    else:
                        return
                    self.show_message("LinnStrument: Shift OFF")
                    return
                if self._session_mode and column == FUNCTION_COLUMN and row == DELETE_MODE_ROW:
                    self._delete_mode = False
                    return
                    self.show_message("LinnStrument: Delete Mode OFF")
                    return

    def _selected_track_index(self):
        try:
            track = self.song().view.selected_track
            tracks = self._tracks()
            if track in tracks:
                return tracks.index(track)
        except Exception:
            pass
        return 0


    def _highlighted_scene_index(self, track=None):
        try:
            slot = self.song().view.highlighted_clip_slot
            if track is not None:
                slots = list(track.clip_slots)
                if slot in slots:
                    return slots.index(slot)
            scenes = list(self.song().scenes)
            # Fallback to current visible scene offset.
            return max(0, int(getattr(self, "_scene_offset", 0)))
        except Exception:
            return max(0, int(getattr(self, "_scene_offset", 0)))


    def _fire_record_clip_on_selected_track(self):
        # Fire the next available empty clip slot on the selected track.
        # Uses the current Fixed Length setting via the existing fixed-length watcher.
        try:
            tracks = self._tracks()
            track_index = self._selected_track_index()
            if track_index >= len(tracks):
                self.show_message("LinnStrument: no selected track")
                return

            track = tracks[track_index]
            start_scene = self._highlighted_scene_index(track)

            target_index = None
            slots = list(track.clip_slots)
            for i in range(start_scene, len(slots)):
                if not self._safe_bool(slots[i], "has_clip"):
                    target_index = i
                    break
            if target_index is None:
                for i in range(0, start_scene):
                    if not self._safe_bool(slots[i], "has_clip"):
                        target_index = i
                        break

            # If no empty slot exists, try to create a new scene at the end.
            if target_index is None:
                try:
                    self.song().create_scene(len(self.song().scenes))
                    slots = list(track.clip_slots)
                    target_index = len(slots) - 1
                except Exception:
                    self.show_message("LinnStrument: no empty clip slot")
                    return

            self._launch_clip(track_index, target_index, force_legato=False, focus_detail=True)
            self.show_message("LinnStrument: Record Clip T%d S%d" % (track_index + 1, target_index + 1))
        except Exception as e:
            try:
                self.log_message("Fire record clip failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: record clip failed")


    def _delete_active_clip_on_selected_track(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _quantize_active_midi_clip_to_16th(self):
        # Best effort: quantize highlighted/detail/playing MIDI clip to 1/16.
        try:
            clip = None
            slot = getattr(self.song().view, "highlighted_clip_slot", None)
            if slot is not None and self._safe_bool(slot, "has_clip"):
                clip = getattr(slot, "clip", None)

            if clip is None:
                detail_clip = getattr(self.song().view, "detail_clip", None)
                if detail_clip is not None:
                    clip = detail_clip

            if clip is None:
                track = self.song().view.selected_track
                for candidate in list(track.clip_slots):
                    if self._safe_bool(candidate, "has_clip") and (
                        self._safe_bool(candidate, "is_playing") or self._safe_bool(candidate, "is_recording")
                    ):
                        clip = getattr(candidate, "clip", None)
                        break

            if clip is None:
                self.show_message("LinnStrument: no active MIDI clip")
                return

            if hasattr(clip, "is_midi_clip") and not bool(clip.is_midi_clip):
                self.show_message("LinnStrument: active clip is not MIDI")
                return

            quant = None
            try:
                q = Live.Clip.GridQuantization
                for name in ("g_16th", "g_sixteenth"):
                    if hasattr(q, name):
                        quant = getattr(q, name)
                        break
            except Exception:
                pass

            if quant is None:
                try:
                    q = Live.Song.Quantization
                    for name in ("q_sixtenth", "q_sixteenth", "q_1_16"):
                        if hasattr(q, name):
                            quant = getattr(q, name)
                            break
                except Exception:
                    pass

            if quant is None:
                self.show_message("LinnStrument: 1/16 quantize unavailable")
                return

            try:
                clip.quantize(quant, 1.0)
                self.show_message("LinnStrument: Quantize Clip 1/16")
            except TypeError:
                clip.quantize(quant)
                self.show_message("LinnStrument: Quantize Clip 1/16")
        except Exception as e:
            try:
                self.log_message("Quantize active MIDI clip failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: quantize failed")


    def _handle_note_mode_function_cc(self, cc, value):
        try:
            value = int(value)
        except Exception:
            value = 0
        # refactor2b: ignore A2/A4 only.
        # These are legacy Session Note Mode functions and are not meaningful in Arrangement_View.
        # LED drawing is intentionally untouched to avoid flicker.
        try:
            for (col, row), mapped_cc in NOTE_MODE_FUNCTION_CCS.items():
                if col == 1 and row in (6, 4) and int(mapped_cc) == int(cc):
                    return True
        except Exception:
            pass

        previous = self._note_mode_cc_states.get(cc, None)
        self._note_mode_cc_states[cc] = value
        if self._session_mode:
            return
        if previous is not None and int(previous) == value:
            return

        if cc == NOTE_MODE_CC_UNDO:
            self.show_message("LinnStrument Note: Undo")
            self._undo()
        elif cc == NOTE_MODE_CC_RECORD_CLIP:
            self._fire_record_clip_on_selected_track()
        elif cc == NOTE_MODE_CC_CAPTURE_MIDI:
            self._capture_midi()
        elif cc == NOTE_MODE_CC_DELETE_ACTIVE_CLIP:
            self._delete_active_clip_on_selected_track()
        elif cc == NOTE_MODE_CC_METRONOME:
            self._toggle_metronome()
            self._draw_note_mode_function_leds()
        elif cc == NOTE_MODE_CC_STOP_SELECTED_TRACK:
            if self._arrangement_view_is_visible():
                self._toggle_play_stop()
            else:
                self._stop_selected_track_clips()
        elif cc == NOTE_MODE_CC_SESSION_RECORD:
            self.show_message("LinnStrument Note: Record")
            self._toggle_context_record()
        elif cc == NOTE_MODE_CC_ENTER_SESSION:
            self.enter_arrangement_mode()




    def _stop_selected_track_clips(self):
        try:
            track = self.song().view.selected_track
            if hasattr(track, "stop_all_clips"):
                track.stop_all_clips()
                self.show_message("LinnStrument: stop selected track")
                return

            for slot in list(track.clip_slots):
                try:
                    if self._safe_bool(slot, "is_playing") or self._safe_bool(slot, "is_recording"):
                        slot.stop()
                except Exception:
                    pass
            self.show_message("LinnStrument: stop selected track")
        except Exception as e:
            try:
                self.log_message("Stop selected track failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: stop selected track failed")

    def _capture_midi(self):
        try:
            song = self.song()
            if hasattr(song, "capture_midi"):
                song.capture_midi()
                self.show_message("LinnStrument Note: Capture MIDI")
            else:
                self.show_message("LinnStrument: capture MIDI not available")
        except Exception as e:
            try:
                self.log_message("Capture MIDI failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: capture MIDI failed")

    def _stop_all_clips(self):
        try:
            self.song().stop_all_clips()
            self.show_message("LinnStrument Note: Stop All Clips")
        except Exception as e:
            try:
                self.log_message("Stop all clips failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: stop all clips failed")

    def _select_adjacent_clip_slot(self, delta):
        try:
            song = self.song()
            track = song.view.selected_track
            slot = song.view.highlighted_clip_slot

            tracks = self._tracks()
            if track not in tracks:
                return

            slots = list(track.clip_slots)
            if not slots:
                return

            if slot in slots:
                index = slots.index(slot)
            else:
                selected_scene = song.view.selected_scene
                scenes = list(song.scenes)
                index = scenes.index(selected_scene) if selected_scene in scenes else 0

            index = max(0, min(len(slots) - 1, index + int(delta)))
            song.view.highlighted_clip_slot = slots[index]

            scenes = list(song.scenes)
            if index < len(scenes):
                song.view.selected_scene = scenes[index]
                if index < self._scene_offset:
                    self._scene_offset = index
                elif index >= self._scene_offset + 5:
                    self._scene_offset = max(0, index - 4)
                self._set_session_highlight()

            self.show_message("LinnStrument: clip slot %d" % (index + 1))
        except Exception as e:
            try:
                self.log_message("Clip navigation failed: %s" % e)
            except Exception:
                pass

    def _delete_highlighted_clip(self):
        try:
            slot = self.song().view.highlighted_clip_slot
            if slot is not None and self._safe_bool(slot, "has_clip"):
                slot.delete_clip()
                self.show_message("LinnStrument: selected clip deleted")
            else:
                self.show_message("LinnStrument: no selected clip")
        except Exception as e:
            try:
                self.log_message("Delete selected clip failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: delete selected clip failed")

    def _scene_index_from_row(self, row):
        return self._scene_offset + (CLIP_ROW_LAST - row)

    def _track_columns(self):
        # LinnStrument_200 Arrangement_View v1.0.3-refactor2b: fixed 8x25 Session layout.
        return 22


    def _fixed_length_column(self):
        # LinnStrument_200 Arrangement_View v1.0.3-refactor2b: fixed-length/control column.
        return 24


    def _scene_column(self):
        # LinnStrument_200 Arrangement_View v1.0.3-refactor2b: scene/shift column.
        return 25


    def _detect_controller_model_from_column(self, column):
        # LinnStrument_200 Arrangement_View v1.0.3-refactor2b: fixed 200 layout; no auto-detection/toggle.
        return


    def _set_session_highlight(self):
        if bool(getattr(self, "_arrangement_mode", False)):
            return

        try:
            self._c_instance.set_session_highlight(
                int(self._track_offset),
                int(self._scene_offset),
                int(self._track_columns()),
                7,
                False
            )
        except Exception as e:
            try:
                self.log_message("Could not set session highlight: %s" % e)
            except Exception:
                pass

    def _clear_session_highlight(self):
        try:
            self._c_instance.set_session_highlight(-1, -1, -1, -1, False)
        except Exception:
            pass

    def enter_session_mode(self):
        # Arrangement_View refactor1:
        # Session View is intentionally disabled in this branch.
        return self.enter_arrangement_mode()


    def _enable_control_exit(self):
        self._allow_control_exit = True

    def enter_note_mode(self):
        self._set_user_mode_expression(y_enabled=False, z_enabled=False)
        self._scrub_pad_held = None
        self._scrub_repeat_active = False
        self._scrub_y_value = 0
        try:
            self._arrangement_mode = False
            self._session_mode = False
            self._mixer_mode = False
            self._delete_mode = False
            self._copy_mode = False
            self._shift = False
            self._allow_control_exit = True
            self._update_counter = 0
            try:
                self._clear_session_highlight()
            except Exception:
                pass
            self._send_nrpn(USER_MODE_NRPN, 0, channel=0)
            self._send_nrpn(USER_MODE_NRPN, 0, channel=15)
            self.show_message("LinnStrument: Note Mode")
            self.log_message("LinnStrument: Note Mode")
            try:
                self._draw_note_mode_function_leds()
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message("enter_note_mode failed: %s" % e)
            except Exception:
                pass


    def _arrangement_view_is_visible(self):
        # v1.10: robust Arrangement View detection.
        try:
            app_view = self.application().view
            if hasattr(app_view, "is_view_visible"):
                for name in ("Arranger", "Arrangement"):
                    try:
                        if bool(app_view.is_view_visible(name)):
                            return True
                    except Exception:
                        pass
                try:
                    if bool(app_view.is_view_visible("Session")):
                        return False
                except Exception:
                    pass
                try:
                    return not bool(app_view.is_view_visible("Session"))
                except Exception:
                    pass
        except Exception:
            pass
        return False


    def _back_to_arrangement_active(self):
        # Best-effort: Ableton exposes this under different names across versions.
        try:
            song = self.song()
            for name in ("back_to_arranger", "back_to_arrangement", "back_to_arranger_enabled"):
                if hasattr(song, name):
                    return bool(getattr(song, name))
        except Exception:
            pass
        return False

    def _trigger_back_to_arrangement(self):
        # Best-effort: return playback focus to Arrangement before/while recording.
        try:
            song = self.song()
            for name in ("back_to_arranger", "back_to_arrangement", "back_to_arranger_enabled"):
                if hasattr(song, name):
                    try:
                        setattr(song, name, False)
                        return True
                    except Exception:
                        pass
            for name in ("trigger_back_to_arranger", "back_to_arranger"):
                attr = getattr(song, name, None)
                if callable(attr):
                    try:
                        attr()
                        return True
                    except Exception:
                        pass
        except Exception:
            pass
        return False

    def _toggle_play_stop_protection(self):
        try:
            self._play_stop_protected = not bool(self._play_stop_protected)
            self.show_message("LinnStrument: Play/Stop %s" % ("protected" if self._play_stop_protected else "unprotected"))
            if self._session_mode:
                self._draw_session_leds()
        except Exception:
            pass

    def _protected_play_stop(self):
        try:
            if self._play_stop_protected:
                self.show_message("LinnStrument: Play/Stop protected")
                return
            self._toggle_play_stop()
        except Exception:
            pass

    def _toggle_play_stop(self):
        song = self.song()
        try:
            if bool(song.is_playing):
                song.stop_playing()
                self.show_message("LinnStrument: Stop")
            else:
                song.start_playing()
                self.show_message("LinnStrument: Play")
        except Exception as e:
            try:
                self.log_message("Play/Stop failed: %s" % e)
            except Exception:
                pass

    def _toggle_context_record(self):
        # v1.3: Pad 7 toggles Session Record in Session View,
        # and Arrangement Record in Arrangement View.
        if self._arrangement_view_is_visible():
            try:
                self._trigger_back_to_arrangement()
                song = self.song()
                song.record_mode = not bool(song.record_mode)
                self.show_message("LinnStrument: Arrangement Record %s" % ("ON" if bool(song.record_mode) else "OFF"))
                return
            except Exception as e:
                try:
                    self.log_message("Arrangement Record failed: %s" % e)
                except Exception:
                    pass
                self.show_message("LinnStrument: Arrangement Record failed")
                return

        self._toggle_session_record()


    def _toggle_session_record(self):
        song = self.song()
        if hasattr(song, "session_record"):
            try:
                song.session_record = not bool(song.session_record)
                return
            except Exception:
                pass
        if hasattr(song, "overdub"):
            try:
                song.overdub = not bool(song.overdub)
            except Exception:
                pass

    def _track_control_mode_name(self):
        if self._track_control_mode == 1:
            return "Solo"
        if self._track_control_mode == 2:
            return "Arm & Select"
        return "Mute / Stop"


    def _set_track_control_mode(self, mode):
        self._track_control_mode = max(0, min(2, int(mode)))
        self.show_message("LinnStrument: Track Control %s" % self._track_control_mode_name())
        self._draw_session_leds()


    def _track_control_button_color(self, mode):
        if mode == 1:
            return self._blink_color(ColorMap.SOLO_ON) if self._track_control_mode == 1 else ColorMap.SOLO_ON
        if mode == 2:
            return self._blink_color(ColorMap.ARM_ON) if self._track_control_mode == 2 else ColorMap.ARM_ON
        return self._blink_color(ColorMap.METRONOME_ON) if self._track_control_mode == 0 else ColorMap.METRONOME_ON


    def _track_control_row_color(self, track_index):
        # v3.10.62: Track-Control row is always lit for better matrix orientation.
        # Uses only existing ColorMap entries:
        # - ColorMap.CAPTURE_SCENE = LSColor.LIME
        # - ColorMap.METRONOME_ON = LSColor.ORANGE
        try:
            tracks = self._tracks()
            if track_index >= len(tracks):
                return ColorMap.EMPTY
            track = tracks[track_index]

            if self._track_control_mode == 1:
                # Solo Mode: active = blue, inactive = lime.
                return ColorMap.SOLO_ON if bool(getattr(track, "solo", False)) else ColorMap.CAPTURE_SCENE

            if self._track_control_mode == 2:
                # Arm Mode: active = red, inactive = lime.
                return ColorMap.ARM_ON if (bool(getattr(track, "arm", False)) or bool(getattr(track, "implicit_arm", False))) else ColorMap.CAPTURE_SCENE

            # Mute Mode: mute active = lime, mute inactive = orange.
            if bool(getattr(track, "mute", False)):
                return ColorMap.CAPTURE_SCENE
            return ColorMap.METRONOME_ON
        except Exception:
            return ColorMap.EMPTY


    def _handle_track_control_row_press(self, track_index):
        if self._track_control_mode == 1:
            self._toggle_solo(track_index)
        elif self._track_control_mode == 2:
            self._toggle_arm_exclusive_and_select(track_index)
        else:
            if self._shift:
                self._stop_track_clips(track_index)
            else:
                self._toggle_track_active(track_index)
        try:
            self._draw_session_leds()
        except Exception:
            pass


    def _handle_grid_press(self, column, row):
        # Arrangement_View refactor2:
        # Session grid / clip launch is disabled in this branch.
        return


    def _start_copy_mode(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _end_copy_mode(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _toggle_copy_scene_mode(self):
        # v1.17: Shift + Pad 2 = Copy Scene Mode.
        self._copy_scene_mode = not bool(self._copy_scene_mode)
        self._copy_scene_source = None
        if self._copy_scene_mode:
            self._copy_mode = False
            self._copy_source = None
        self.show_message("LinnStrument: Copy Scene Mode %s" % ("ON" if self._copy_scene_mode else "OFF"))
        try:
            self._draw_session_leds()
        except Exception:
            pass


    def _track_kind(self, track):
        try:
            if bool(getattr(track, "has_midi_input", False)):
                return "midi"
        except Exception:
            pass
        try:
            if bool(getattr(track, "has_audio_input", False)):
                return "audio"
        except Exception:
            pass
        return None

    def _clip_kind(self, slot):
        try:
            if slot is not None and self._safe_bool(slot, "has_clip"):
                clip = getattr(slot, "clip", None)
                if clip is not None:
                    if bool(getattr(clip, "is_midi_clip", False)):
                        return "midi"
                    if bool(getattr(clip, "is_audio_clip", False)):
                        return "audio"
        except Exception:
            pass
        return None

    def _copy_track_types_allowed(self, source_track, target_track, source_slot):
        try:
            source_kind = self._clip_kind(source_slot)
            if source_kind is None:
                source_kind = self._track_kind(source_track)
            target_kind = self._track_kind(target_track)

            if source_kind is not None and target_kind is not None and source_kind != target_kind:
                self.show_message("LinnStrument: copy only MIDI→MIDI or Audio→Audio")
                try:
                    self._copy_mode = False
                    self._copy_source = None
                    self._draw_session_leds()
                except Exception:
                    pass
                return False
        except Exception:
            pass
        return True

    def _handle_copy_clip_press(self, track_index, scene_index):
        tracks = self._tracks()
        try:
            if track_index >= len(tracks):
                return
            target_track = tracks[track_index]
            if scene_index >= len(target_track.clip_slots):
                return
            target_slot = target_track.clip_slots[scene_index]

            if self._copy_source is None:
                if not self._safe_bool(target_slot, "has_clip"):
                    self.show_message("LinnStrument: select clip or scene to copy")
                    return
                self._copy_source_type = "clip"
                self._copy_source = (track_index, scene_index)
                self.show_message("LinnStrument: copy clip source selected")
                try:
                    self._draw_session_leds()
                except Exception:
                    pass
                return

            if self._copy_source_type != "clip":
                self.show_message("LinnStrument: select scene target")
                return

            source_track_index, source_scene_index = self._copy_source
            if source_track_index >= len(tracks):
                self.show_message("LinnStrument: copy source invalid")
                self._copy_source = None
                return
            source_track = tracks[source_track_index]
            if source_scene_index >= len(source_track.clip_slots):
                self.show_message("LinnStrument: copy source invalid")
                self._copy_source = None
                return

            source_slot = source_track.clip_slots[source_scene_index]

            if not self._safe_bool(source_slot, "has_clip"):
                self.show_message("LinnStrument: copy source empty")
                self._copy_source = None
                return

            if self._safe_bool(target_slot, "has_clip"):
                self.show_message("LinnStrument: target slot not empty")
                self._copy_source = None
                self._copy_source_type = None
                try:
                    self._draw_session_leds()
                except Exception:
                    pass
                return

            if not self._copy_track_types_allowed(source_track, target_track, source_slot):
                return

            try:
                if hasattr(source_slot, "duplicate_clip_to"):
                    source_slot.duplicate_clip_to(target_slot)
                elif source_track == target_track and hasattr(source_track, "duplicate_clip_slot"):
                    source_track.duplicate_clip_slot(source_scene_index, scene_index)
                else:
                    self.show_message("LinnStrument: copy unavailable")
                    return
            except Exception as e:
                try:
                    self.log_message("Copy clip failed: %s" % e)
                except Exception:
                    pass
                self.show_message("LinnStrument: copy failed")
                return

            self._last_pressed_track_index = track_index
            self._last_pressed_scene_index = scene_index
            self._copy_source = None
            self._copy_source_type = None
            self.show_message("LinnStrument: copied clip")
            try:
                self._draw_session_leds()
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message("Copy mode failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: copy failed")

    def _copy_scene_mode_button_color(self):
        try:
            if self._copy_mode:
                return self._blink_color(ColorMap.DELETE_MODE_ON)
        except Exception:
            pass
        return ColorMap.MAGENTA


    def _scene_is_empty(self, scene_index):
        try:
            for track in self._tracks():
                try:
                    if scene_index < len(track.clip_slots) and self._safe_bool(track.clip_slots[scene_index], "has_clip"):
                        return False
                except Exception:
                    pass
        except Exception:
            pass
        return True

    def _handle_copy_scene_press(self, scene_index):
        try:
            scenes = list(self.song().scenes)
            if scene_index >= len(scenes):
                return

            if self._copy_source is None:
                has_clip = False
                for track in self._tracks():
                    try:
                        if scene_index < len(track.clip_slots) and self._safe_bool(track.clip_slots[scene_index], "has_clip"):
                            has_clip = True
                            break
                    except Exception:
                        pass
                if not has_clip:
                    self.show_message("LinnStrument: select scene with clips")
                    return
                self._copy_source_type = "scene"
                self._copy_source = scene_index
                self.show_message("LinnStrument: copy scene source selected")
                self._draw_session_leds()
                return

            if self._copy_source_type != "scene":
                self.show_message("LinnStrument: select clip target")
                return

            source_index = self._copy_source
            target_index = scene_index

            if not self._scene_is_empty(target_index):
                self.show_message("LinnStrument: target scene not empty")
                self._copy_source = None
                self._copy_source_type = None
                try:
                    self._draw_session_leds()
                except Exception:
                    pass
                return

            copied = 0
            for track in self._tracks():
                try:
                    if source_index >= len(track.clip_slots) or target_index >= len(track.clip_slots):
                        continue
                    source_slot = track.clip_slots[source_index]
                    target_slot = track.clip_slots[target_index]
                    if not self._safe_bool(source_slot, "has_clip"):
                        continue
                    if hasattr(source_slot, "duplicate_clip_to"):
                        source_slot.duplicate_clip_to(target_slot)
                        copied += 1
                except Exception as e:
                    try:
                        self.log_message("Copy scene slot failed: %s" % e)
                    except Exception:
                        pass

            if copied <= 0:
                self.show_message("LinnStrument: copy scene failed")
                return

            self._copy_source = None
            self._copy_source_type = None
            self.show_message("LinnStrument: copied scene")
            try:
                self._draw_session_leds()
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message("Copy scene failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: copy scene failed")


    def _copy_mode_button_color(self):
        try:
            if self._copy_mode:
                return self._blink_color(ColorMap.DELETE_MODE_ON)
        except Exception:
            pass
        return ColorMap.CAPTURE_SCENE

    def _toggle_launch_quantization_1bar_none(self):
        try:
            song = self.song()
            current = int(getattr(song, "clip_trigger_quantization", 4))

            # Ableton Live quantization enum values:
            # 0 = None, 4 = 1 Bar.
            if current == 0:
                song.clip_trigger_quantization = 4
                self.show_message("LinnStrument: Launch Quantization 1 Bar")
            else:
                song.clip_trigger_quantization = 0
                self.show_message("LinnStrument: Launch Quantization None")

            try:
                self._draw_session_leds()
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message("Launch Quantization toggle failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: Launch Quantization failed")

    def _launch_quantization_shift_color(self):
        try:
            current = int(getattr(self.song(), "clip_trigger_quantization", 4))
            if current == 0:
                return ColorMap.DELETE_MODE_ON
            return ColorMap.PLAY_ON
        except Exception:
            return ColorMap.PLAY_ON

    def _handle_function_column(self, row):
        # Arrangement_View refactor2:
        # Session function column is disabled. A8/other session functions are not active.
        return


    def _undo(self):
        try:
            self.song().undo()
            self.show_message("LinnStrument: Undo")
        except Exception as e:
            try:
                self.log_message("Undo failed: %s" % e)
            except Exception:
                pass

    def _redo(self):
        try:
            self.song().redo()
            self.show_message("LinnStrument: Redo")
        except Exception as e:
            try:
                self.log_message("Redo failed: %s" % e)
            except Exception:
                pass


    def _duplicate_selected_clip(self):
        try:
            source = self._preferred_duplicate_source()
            if source is None:
                self.show_message("LinnStrument: no clip to duplicate")
                return

            track, source_index = source
            slots = list(track.clip_slots)
            if source_index >= len(slots) or not self._safe_bool(slots[source_index], "has_clip"):
                self.show_message("LinnStrument: no clip to duplicate")
                return

            target_index = self._next_duplicate_target_index(track, source_index)
            if target_index is None:
                self.show_message("LinnStrument: duplicate target failed")
                return

            try:
                track.duplicate_clip_slot(source_index, target_index)
            except TypeError:
                try:
                    track.duplicate_clip_slot(source_index)
                except Exception:
                    raise

            self._last_pressed_track_index = self._track_index(track)
            self._last_pressed_scene_index = target_index
            self.show_message("LinnStrument: duplicated clip")
        except Exception as e:
            try:
                self.log_message("Duplicate clip failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: duplicate failed")

    def _next_duplicate_target_index(self, track, source_index):
        try:
            slots = list(track.clip_slots)
            target_index = source_index + 1

            if target_index >= len(self.song().scenes):
                self.song().create_scene(len(self.song().scenes))
                slots = list(track.clip_slots)

            while target_index < len(slots) and self._safe_bool(slots[target_index], "has_clip"):
                target_index += 1

            if target_index >= len(slots):
                self.song().create_scene(len(self.song().scenes))

            return target_index
        except Exception as e:
            try:
                self.log_message("Target index failed: %s" % e)
            except Exception:
                pass
            return None

    def _preferred_duplicate_source(self):
        tracks = self._tracks()

        try:
            if self._last_pressed_track_index is not None and self._last_pressed_scene_index is not None:
                if self._last_pressed_track_index < len(tracks):
                    track = tracks[self._last_pressed_track_index]
                    if self._last_pressed_scene_index < len(track.clip_slots):
                        slot = track.clip_slots[self._last_pressed_scene_index]
                        if self._safe_bool(slot, "has_clip"):
                            return (track, self._last_pressed_scene_index)
        except Exception:
            pass

        try:
            slot = self.song().view.highlighted_clip_slot
            if slot is not None and self._safe_bool(slot, "has_clip"):
                for track in tracks:
                    slots = list(track.clip_slots)
                    if slot in slots:
                        return (track, slots.index(slot))
        except Exception:
            pass

        try:
            selected = self.song().view.selected_track
            if selected in tracks:
                for index, slot in enumerate(list(selected.clip_slots)):
                    if self._safe_bool(slot, "is_playing") and self._safe_bool(slot, "has_clip"):
                        return (selected, index)
        except Exception:
            pass

        try:
            for track in tracks:
                for index, slot in enumerate(list(track.clip_slots)):
                    if self._safe_bool(slot, "is_playing") and self._safe_bool(slot, "has_clip"):
                        return (track, index)
        except Exception:
            pass

        return None

    def _track_index(self, track):
        try:
            tracks = self._tracks()
            if track in tracks:
                return tracks.index(track)
        except Exception:
            pass
        return None

    def _duplicate_selected_scene(self):
        try:
            song = self.song()
            scenes = list(song.scenes)
            selected_scene = song.view.selected_scene
            if selected_scene not in scenes:
                self.show_message("LinnStrument: no selected scene")
                return
            source_index = scenes.index(selected_scene)
            if hasattr(song, "duplicate_scene"):
                song.duplicate_scene(source_index)
            else:
                self.show_message("LinnStrument: duplicate scene not available")
                return
            try:
                scenes = list(song.scenes)
                target_index = source_index + 1
                if target_index < len(scenes):
                    song.view.selected_scene = scenes[target_index]
                    if target_index < self._scene_offset:
                        self._scene_offset = target_index
                    elif target_index >= self._scene_offset + 5:
                        self._scene_offset = max(0, target_index - 4)
                    self._set_session_highlight()
            except Exception:
                pass
            self.show_message("LinnStrument: duplicated scene")
        except Exception as e:
            try:
                self.log_message("Duplicate scene failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: duplicate scene failed")

    def _capture_and_insert_scene(self):
        song = self.song()
        try:
            song.capture_and_insert_scene()
            self.show_message("LinnStrument: captured and inserted scene")
        except Exception as e:
            try:
                self.log_message("Could not capture and insert scene: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: capture scene not available")

        try:
            selected_scene = song.view.selected_scene
            scenes = list(song.scenes)
            if selected_scene in scenes:
                selected_index = scenes.index(selected_scene)
                if selected_index < self._scene_offset:
                    self._scene_offset = selected_index
                elif selected_index >= self._scene_offset + 5:
                    self._scene_offset = max(0, selected_index - 4)
        except Exception:
            pass

        self._set_session_highlight()

    def _handle_scene_column(self, row):
        if CLIP_ROW_FIRST <= row <= CLIP_ROW_LAST:
            scene_index = self._scene_index_from_row(row)
            if self._copy_mode:
                self._handle_copy_scene_press(scene_index)
            elif self._delete_mode:
                self._delete_scene(scene_index)
            else:
                self._launch_scene(scene_index, force_legato=self._shift)
        elif row == SHIFT_ROW:
            # Momentary Shift: press = on, release handled in receive_midi.
            self._shift = True
            self.show_message("LinnStrument: Shift ON")


    def _track_should_auto_note_switch(self, track_index):
        # v3.10.33: Auto Session -> Note only for MIDI tracks.
        # Audio tracks should stay in Session Mode for audio/live microphone looping.
        try:
            tracks = self._tracks()
            if track_index >= len(tracks):
                return False
            track = tracks[track_index]

            # Ableton MIDI tracks normally expose has_midi_input = True.
            if bool(getattr(track, "has_midi_input", False)):
                return True

            # Explicitly prevent auto-switch on audio tracks.
            if bool(getattr(track, "has_audio_input", False)):
                return False

            return False
        except Exception:
            return False

    def _clip_slot_should_return_to_note(self, track_index, scene_index):
        # v3.10.5: Auto-return Session -> Note only for recording/overdub workflows.
        # Do not return to Note Mode when merely launching an existing clip for playback.
        try:
            tracks = self._tracks()
            if track_index >= len(tracks):
                return False
            if scene_index >= len(tracks[track_index].clip_slots):
                return False

            track = tracks[track_index]
            slot = track.clip_slots[scene_index]

            # Empty slot on an armed track: firing starts recording a new clip.
            if not self._safe_bool(slot, "has_clip"):
                return bool(getattr(track, "arm", False)) or bool(getattr(track, "implicit_arm", False))

            # Slot already recording: firing is part of recording workflow.
            if self._safe_bool(slot, "is_recording"):
                return True

            clip = getattr(slot, "clip", None)
            if clip is not None and self._safe_bool(clip, "is_recording"):
                return True

            # Existing playing clip while Session Record/Overdub is active: likely overdub.
            if self._safe_bool(slot, "is_playing"):
                song = self.song()
                if bool(getattr(song, "session_record", False)):
                    return True
                if bool(getattr(song, "overdub", False)):
                    return True

            return False
        except Exception as e:
            try:
                self.log_message("Return-to-note check failed: %s" % e)
            except Exception:
                pass
            return False

    def _show_clip_slot_in_detail_view(self, slot):
        # Best-effort: make Ableton show the selected/created clip in Detail/Clip/Piano-Roll view.
        try:
            song = self.song()
            song.view.highlighted_clip_slot = slot
            clip = getattr(slot, "clip", None)
            if clip is not None:
                try:
                    song.view.detail_clip = clip
                except Exception:
                    pass
                try:
                    song.view.selected_clip = clip
                except Exception:
                    pass
            try:
                self.application().view.show_view("Detail")
                self.application().view.show_view("Detail/Clip")
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message("Show clip detail failed: %s" % e)
            except Exception:
                pass

    def _schedule_clip_slot_detail_view(self, slot):
        # Clip creation after launch is asynchronous in Live.
        # Retry a few times so new recordings/overdubs get focus reliably.
        try:
            self._show_clip_slot_in_detail_view(slot)
            self.schedule_message(2, lambda: self._show_clip_slot_in_detail_view(slot))
            self.schedule_message(8, lambda: self._show_clip_slot_in_detail_view(slot))
            self.schedule_message(16, lambda: self._show_clip_slot_in_detail_view(slot))
        except Exception:
            try:
                self._show_clip_slot_in_detail_view(slot)
            except Exception:
                pass

    def _quantization_value(self, names):
        try:
            quant = Live.Song.Quantization
            for name in names:
                if hasattr(quant, name):
                    return getattr(quant, name)
        except Exception:
            pass
        return None

    def _set_global_launch_quantization(self, row):
        mapping = {
            LAUNCH_QUANT_1_BAR_ROW: ("1 Bar", ("q_bar", "q_1_bar")),
            LAUNCH_QUANT_1_4_ROW: ("1/4", ("q_quarter", "q_1_4")),
            LAUNCH_QUANT_1_8_ROW: ("1/8", ("q_eight", "q_1_8")),
            LAUNCH_QUANT_1_16_ROW: ("1/16", ("q_sixtenth", "q_sixteenth", "q_1_16")),
        }
        if row not in mapping:
            return

        label, enum_names = mapping[row]
        value = self._quantization_value(enum_names)
        if value is None:
            self.show_message("LinnStrument: quantization %s not available" % label)
            return

        try:
            self.song().clip_trigger_quantization = value
            self._launch_quant_row = row
            self.show_message("LinnStrument: Launch Quantization %s" % label)
            self._draw_session_leds()
        except Exception as e:
            try:
                self.log_message("Set launch quantization failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: launch quantization failed")

    def _current_launch_quant_row(self):
        try:
            current = self.song().clip_trigger_quantization
            for row, names in (
                (LAUNCH_QUANT_1_BAR_ROW, ("q_bar", "q_1_bar")),
                (LAUNCH_QUANT_1_4_ROW, ("q_quarter", "q_1_4")),
                (LAUNCH_QUANT_1_8_ROW, ("q_eight", "q_1_8")),
                (LAUNCH_QUANT_1_16_ROW, ("q_sixtenth", "q_sixteenth", "q_1_16")),
            ):
                value = self._quantization_value(names)
                if value is not None and current == value:
                    return row
        except Exception:
            pass
        return self._launch_quant_row

    def _launch_quant_color(self, row):
        return self._blink_color(ColorMap.LIGHT_BLUE) if self._current_launch_quant_row() == row else ColorMap.LIGHT_BLUE

    def _draw_launch_quantization_pads(self):
        self._set_pad_color(self._fixed_length_column(), LAUNCH_QUANT_1_BAR_ROW, self._launch_quant_color(LAUNCH_QUANT_1_BAR_ROW))
        self._set_pad_color(self._fixed_length_column(), LAUNCH_QUANT_1_4_ROW, self._launch_quant_color(LAUNCH_QUANT_1_4_ROW))
        self._set_pad_color(self._fixed_length_column(), LAUNCH_QUANT_1_8_ROW, self._launch_quant_color(LAUNCH_QUANT_1_8_ROW))
        self._set_pad_color(self._fixed_length_column(), LAUNCH_QUANT_1_16_ROW, self._launch_quant_color(LAUNCH_QUANT_1_16_ROW))

    def _enable_user_mode_y_diagnostic(self):
        # v3.10.48-y-diagnostic:
        # Enable User Firmware Mode Y-axis output on row channels 1-8.
        # Expected result in MIDI Monitor while touching/moving pads:
        # CC64+column with values 0..127 on the row/channel.
        try:
            for channel in range(8):
                self._send_midi((0xB0 | channel, 11, 1))
            self.show_message("LinnStrument: Mixer Y Fine ON")
            self.log_message("LinnStrument: Mixer Y Fine ON (CC11=1 ch1-8)")
        except Exception as e:
            try:
                self.log_message("Enable Mixer Y Fine failed: %s" % e)
            except Exception:
                pass

    def _disable_user_mode_y_diagnostic(self):
        try:
            for channel in range(8):
                self._send_midi((0xB0 | channel, 11, 0))
            self.log_message("LinnStrument: Mixer Y Fine OFF (CC11=0 ch1-8)")
        except Exception:
            pass

    def _toggle_mixer_mode(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _mixer_level_for_row(self, row):
        # 8 coarse volume levels, bottom to top.
        # Row 0 = 12.5%, Row 7 = 100%.
        try:
            row = max(0, min(7, int(row)))
        except Exception:
            row = 0
        return float(row + 1) / 8.0

    def _row_for_mixer_level(self, value):
        try:
            value = float(value)
        except Exception:
            value = 0.0
        value = max(0.0, min(1.0, value))
        return max(0, min(7, int(round((value * 8.0) - 1.0))))

    def _mixer_fine_range_for_row(self, row):
        # Row channels are bottom=0..top=7. Use each row as a 1/8 volume band.
        try:
            row = max(0, min(7, int(row)))
        except Exception:
            row = 0
        low = float(row) / 8.0
        high = float(row + 1) / 8.0
        return low, high

    def _set_track_volume_from_y(self, track_index, row, value):
        # v3.10.54: Slew limiter + short momentum support.
        try:
            tracks = self._tracks()
            if track_index >= len(tracks):
                return

            value = max(0, min(127, int(value)))

            # Estimate Y velocity for short gap-glide between physical pads.
            last_y = self._mixer_fine_last_y.get(track_index)
            if last_y is not None:
                velocity = float(value - last_y)
                # Clamp extreme jumps from finger geometry / pad boundary changes.
                if velocity > 18.0:
                    velocity = 18.0
                elif velocity < -18.0:
                    velocity = -18.0
                self._mixer_fine_velocity[track_index] = velocity
            else:
                self._mixer_fine_velocity[track_index] = 0.0
            self._mixer_fine_last_y[track_index] = value
            self._mixer_fine_glide_counts[track_index] = 0

            latched_row = self._mixer_fine_active.get(track_index, row)
            low, high = self._mixer_fine_range_for_row(latched_row)
            target_level = low + ((high - low) * (float(value) / 127.0))
            target_level = max(0.0, min(1.0, target_level))

            try:
                current_level = float(tracks[track_index].mixer_device.volume.value)
            except Exception:
                current_level = target_level

            max_step = 0.018
            delta = target_level - current_level
            if delta > max_step:
                level = current_level + max_step
            elif delta < -max_step:
                level = current_level - max_step
            else:
                level = target_level

            level = max(0.0, min(1.0, level))
            if abs(current_level - level) < 0.003:
                return

            tracks[track_index].mixer_device.volume.value = level
            self._mixer_fine_levels[track_index] = level
            column = PLAYABLE_COLUMN_FIRST + (track_index - self._track_offset)
            self._draw_mixer_column(column)
        except Exception as e:
            try:
                self.log_message("Mixer Y fine volume failed: %s" % e)
            except Exception:
                pass

    def _mixer_gap_glide_tick(self):
        # Continue the last Y direction briefly when no Y CCs arrive while crossing
        # the physical gap between two LinnStrument pads.
        if not self._session_mode or not self._mixer_mode:
            return

        try:
            for track_index in list(self._mixer_fine_velocity.keys()):
                if track_index not in self._mixer_fine_active:
                    continue

                velocity = float(self._mixer_fine_velocity.get(track_index, 0.0))
                if abs(velocity) < 1.0:
                    continue

                count = int(self._mixer_fine_glide_counts.get(track_index, 0))
                if count >= 3:
                    continue

                last_y = float(self._mixer_fine_last_y.get(track_index, 0.0))
                predicted_y = last_y + (velocity * 0.45)
                predicted_y = max(0.0, min(127.0, predicted_y))

                self._mixer_fine_last_y[track_index] = predicted_y
                self._mixer_fine_glide_counts[track_index] = count + 1

                row = self._mixer_fine_active.get(track_index, 0)
                self._set_track_volume_from_y(track_index, row, int(predicted_y))
        except Exception as e:
            try:
                self.log_message("Mixer gap glide failed: %s" % e)
            except Exception:
                pass


    def _set_track_volume_from_mixer_row(self, track_index, row):
        try:
            tracks = self._tracks()
            if track_index >= len(tracks):
                return
            # Latch the coarse row. If the track is already active, update the latch
            # but avoid repeated hard jumps from additional Note On events while sliding.
            already_active = int(track_index) in self._mixer_fine_active
            self._mixer_fine_active[int(track_index)] = int(row)

            if not already_active:
                level = self._mixer_level_for_row(row)
                tracks[track_index].mixer_device.volume.value = level
                self.show_message("LinnStrument: Track %d volume %d%%" % (track_index + 1, int(level * 100)))
                column = PLAYABLE_COLUMN_FIRST + (track_index - self._track_offset)
                self._draw_mixer_column(column)
        except Exception as e:
            try:
                self.log_message("Mixer volume set failed: %s" % e)
            except Exception:
                pass

    def _clear_mixer_non_fader_columns(self):
        # v1.1: In Mixer Mode, only fader columns plus the Mixer Mode button should be visible.
        # Clear stale Session/Function LEDs on:
        # - column 1 function column
        # - dynamic Fixed Length / Mixer / TC column
        # - dynamic Scene / Shift column
        try:
            columns = set([FUNCTION_COLUMN, self._fixed_length_column(), self._scene_column()])
            for column in columns:
                for row in range(0, 8):
                    self._set_pad_color(column, row, ColorMap.EMPTY)
        except Exception:
            pass

    def _clear_mixer_surface(self):
        # Clear once when entering/banking Mixer Mode to avoid LED leftovers.
        # Do not call this on every refresh, otherwise the LinnStrument flickers.
        for column in range(1, self._controller_columns + 1):
            for row in range(0, 8):
                self._set_pad_color(column, row, ColorMap.EMPTY)

    def _mixer_track_color(self, track_index):
        # v3.10.20: use the exact same track-color method as Session clip colors.
        try:
            color = self._track_fixed_clip_color(track_index)
            if color != ColorMap.EMPTY:
                return color
        except Exception:
            pass
        return ColorMap.MIXER_ON

    def _draw_mixer_column(self, column):
        # v3.10.55: fast LED update for one mixer fader column.
        if not self._session_mode or not self._mixer_mode:
            return
        try:
            tracks = self._tracks()
            if column < PLAYABLE_COLUMN_FIRST or column >= PLAYABLE_COLUMN_FIRST + self._track_columns():
                return

            track_index = self._track_offset + (column - PLAYABLE_COLUMN_FIRST)
            current_row = -1
            color = ColorMap.MIXER_ON

            if track_index < len(tracks):
                try:
                    track = tracks[track_index]
                    current_row = self._row_for_mixer_level(track.mixer_device.volume.value)
                    color = self._mixer_track_color(track_index)
                except Exception:
                    current_row = -1

            for row in range(0, 8):
                if row <= current_row:
                    self._set_pad_color(column, row, color)
                else:
                    self._set_pad_color(column, row, ColorMap.EMPTY)

            self._clear_mixer_non_fader_columns()
        except Exception as e:
            try:
                self.log_message("Mixer column redraw failed: %s" % e)
            except Exception:
                pass

    def _draw_mixer_grid(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _mixer_mode_button_color(self):
        # v3.10.70: Mixer Mode button is white, blinking when active.
        return self._blink_color(ColorMap.WHITE) if self._mixer_mode else ColorMap.WHITE


    def _set_arrangement_launch_quantization(self, label, enum_names, fallback_value=None):
        """Set Live's global clip-launch quantization from Arrangement Mode."""
        try:
            value = self._quantization_value(tuple(enum_names))
            if value is None and fallback_value is not None:
                value = int(fallback_value)
            if value is None:
                self.show_message(
                    "LinnStrument Arrangement: Launch Quantization %s unavailable"
                    % str(label)
                )
                return False

            self.song().clip_trigger_quantization = value
            self.show_message(
                "LinnStrument Arrangement: Launch Quantization %s" % str(label)
            )
            return True
        except Exception as e:
            try:
                self.log_message(
                    "Arrangement launch quantization %s failed: %s"
                    % (str(label), e)
                )
            except Exception:
                pass
            self.show_message(
                "LinnStrument Arrangement: Launch Quantization failed"
            )
            return False

    def _arrangement_tap_tempo(self):
        try:
            song = self.song()
            tap = getattr(song, "tap_tempo", None)
            if callable(tap):
                tap()
                self.show_message("LinnStrument Arrangement: Tap Tempo")
                return True
            self.show_message("LinnStrument Arrangement: Tap Tempo unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement Tap Tempo failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument Arrangement: Tap Tempo failed")
        return False

    def _change_tempo(self, delta):
        try:
            song = self.song()
            song.tempo = max(20.0, min(999.0, float(song.tempo) + float(delta)))
            self.show_message("LinnStrument: Tempo %.1f BPM" % float(song.tempo))
        except Exception as e:
            try:
                self.log_message("Tempo change failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: Tempo failed")

    def _tempo_shift_button_color(self):
        return ColorMap.PLAY_ON if self._shift else ColorMap.EMPTY

    def _stop_all_clips(self):
        try:
            song = self.song()
            if hasattr(song, "stop_all_clips"):
                song.stop_all_clips()
                self.show_message("LinnStrument: Stop all clips")
                return

            for track in self._tracks():
                try:
                    if hasattr(track, "stop_all_clips"):
                        track.stop_all_clips()
                except Exception:
                    pass
            self.show_message("LinnStrument: Stop all clips")
        except Exception as e:
            try:
                self.log_message("Stop all clips failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: Stop all clips failed")

    def _osc_pad(self, text):
        b = bytearray(str(text).encode("utf-8"))
        b.append(0)
        while len(b) % 4:
            b.append(0)
        return bytes(b)

    def _scrub_debug(self, message):
        pass

    def _osc_pad(self, text):
        data = bytearray(str(text).encode("utf-8")); data.append(0)
        while len(data) % 4: data.append(0)
        return bytes(data)

    def _set_user_mode_expression(self, y_enabled=False, z_enabled=False):
        # User Firmware Mode: CC11 = Y, CC12 = Z, per row channel.
        try:
            for channel in range(8):
                self._send_midi((0xB0 | channel, 11, 1 if y_enabled else 0))
                self._send_midi((0xB0 | channel, 12, 1 if z_enabled else 0))
            self.log_message("LinnStrument expression: Y=%s Z=%s" % (bool(y_enabled), bool(z_enabled)))
        except Exception as e:
            self.log_message("Set expression mode failed: %s" % e)

    def _scrub_amount_from_y(self, value):
        """Quadratic musical range: 0=.25 beat, ~64=1 beat, 127=4 beats."""
        try: value = max(0, min(127, int(value)))
        except Exception: value = 0
        normalized = float(value) / 127.0
        return 0.25 + (normalized * normalized * 3.75)

    def _scrub_tick(self):
        try:
            active_pad = getattr(self, "_scrub_pad_held", None)
            if not bool(getattr(self, "_arrangement_mode", False)) or active_pad not in ("N4", "P4"):
                self._scrub_repeat_active = False
                return
            magnitude = self._scrub_amount_from_y(getattr(self, "_scrub_y_value", 0))
            amount = -magnitude if active_pad == "N4" else magnitude
            self._scrub_debug("TICK pad=%s y=%d amount=%.6f" % (
                active_pad, int(getattr(self, "_scrub_y_value", 0)), float(amount)))
            self._send_scrub_osc(amount)
            self.schedule_message(1, self._scrub_tick)
        except Exception as e:
            self._scrub_repeat_active = False
            self._scrub_debug("TICK ERROR: %s" % e)

    def _send_scrub_osc(self, amount):
        try:
            if self._arrangement_udp_socket is None:
                self._arrangement_udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            packet = self._osc_pad("/lsscrub") + self._osc_pad(",f") + struct.pack(">f", float(amount))
            self._arrangement_udp_socket.sendto(packet, (self._arrangement_udp_host, int(self._scrub_udp_port)))
        except Exception as e:
            self._scrub_debug("UDP ERROR: %s" % e)
            self.show_message("N4/P4 scrub UDP failed: %s" % e)

    def _send_track_zoom_osc(self, direction):
        """Send PAM-compatible vertical zoom direction to the Companion."""
        try:
            if direction not in ("up", "down"):
                return
            if self._arrangement_udp_socket is None:
                self._arrangement_udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            packet = self._osc_pad("/lstrackzoom/%s" % direction) + self._osc_pad(",")
            self._arrangement_udp_socket.sendto(
                packet,
                (self._arrangement_udp_host, int(self._scrub_udp_port)),
            )
        except Exception as e:
            try:
                self.log_message("Vertical track zoom UDP failed: %s" % e)
            except Exception:
                pass

    def _track_zoom_tick(self):
        try:
            direction = getattr(self, "_track_zoom_held", None)
            if not bool(getattr(self, "_arrangement_mode", False)) or direction not in ("up", "down"):
                self._track_zoom_repeat_active = False
                return
            self._send_track_zoom_osc(direction)
            self.schedule_message(2, self._track_zoom_tick)
        except Exception as e:
            self._track_zoom_repeat_active = False
            try:
                self.log_message("Vertical track zoom repeat failed: %s" % e)
            except Exception:
                pass

    def _start_track_zoom(self, direction):
        if direction not in ("up", "down"):
            return
        self._track_zoom_held = direction
        if not self._track_zoom_repeat_active:
            self._track_zoom_repeat_active = True
            self._track_zoom_tick()

    def _stop_track_zoom(self, direction):
        if getattr(self, "_track_zoom_held", None) == direction:
            self._track_zoom_held = None
            self._track_zoom_repeat_active = False
            self._arrangement_clear_active_track_faders()
            self._arrangement_last_selected_track_object = self.song().view.selected_track
            self._arrangement_pan_led_states = {}
            self._draw_arrangement_active_track_mixer()

    def _send_arrangement_osc(self, command):
        try:
            if self._arrangement_udp_socket is None:
                self._arrangement_udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            packet = self._osc_pad("/lsarr/%s" % command) + self._osc_pad(",")
            self._arrangement_udp_socket.sendto(packet, (self._arrangement_udp_host, int(self._arrangement_udp_port)))
            self.log_message("LinnStrument Arrangement UDP: %s" % command)
        except Exception as e:
            try:
                self.log_message("Arrangement UDP send failed: %s" % e)
            except Exception:
                pass

    def _arrangement_toggle_metronome(self):
        try:
            song = self.song()
            song.metronome = not bool(song.metronome)
            self.show_message("LinnStrument Arrangement: Metronome %s" % ("ON" if song.metronome else "OFF"))
        except Exception as e:
            try:
                self.log_message("Arrangement metronome failed: %s" % e)
            except Exception:
                pass

    def _arrangement_play_stop(self):
        try:
            song = self.song()
            if bool(song.is_playing):
                song.stop_playing()
            else:
                song.start_playing()
            self.show_message("LinnStrument Arrangement: Play/Stop")
        except Exception as e:
            try:
                self.log_message("Arrangement play/stop failed: %s" % e)
            except Exception:
                pass

    def _arrangement_continue_play(self):
        try:
            song = self.song()
            if hasattr(song, "continue_playing"):
                song.continue_playing()
            else:
                song.start_playing()
            self.show_message("LinnStrument Arrangement: Continue Play")
        except Exception as e:
            try:
                self.log_message("Arrangement continue play failed: %s" % e)
            except Exception:
                pass

    def _arrangement_record(self):
        try:
            song = self.song()
            song.record_mode = not bool(song.record_mode)
            self.show_message("LinnStrument Arrangement: Record %s" % ("ON" if song.record_mode else "OFF"))
        except Exception as e:
            try:
                self.log_message("Arrangement record failed: %s" % e)
            except Exception:
                pass

    def _selected_track_for_arrangement(self):
        try:
            return self.song().view.selected_track
        except Exception:
            return None

    def _arrangement_toggle_selected_track_mute(self):
        try:
            track = self._selected_track_for_arrangement()
            if track is not None and hasattr(track, "mute"):
                track.mute = not bool(track.mute)
                self.show_message("LinnStrument Arrangement: Track Mute %s" % ("ON" if track.mute else "OFF"))
        except Exception as e:
            try:
                self.log_message("Arrangement track mute failed: %s" % e)
            except Exception:
                pass

    def _arrangement_toggle_selected_track_solo(self):
        try:
            track = self._selected_track_for_arrangement()
            if track is not None and hasattr(track, "solo"):
                track.solo = not bool(track.solo)
                self.show_message("LinnStrument Arrangement: Track Solo %s" % ("ON" if track.solo else "OFF"))
        except Exception as e:
            try:
                self.log_message("Arrangement track solo failed: %s" % e)
            except Exception:
                pass

    def _arrangement_toggle_selected_track_arm(self):
        # v1.46: Exclusive arm. At most one normal track is armed.
        try:
            selected = self._selected_track_for_arrangement()
            if selected is None or not bool(getattr(selected, "can_be_armed", False)):
                self.show_message("LinnStrument Arrangement: selected track cannot be armed")
                return

            target_state = not bool(getattr(selected, "arm", False))

            # Always unarm all other armable tracks first.
            try:
                for track in list(self.song().tracks):
                    try:
                        if track is not selected and bool(getattr(track, "can_be_armed", False)):
                            track.arm = False
                    except Exception:
                        pass
            except Exception:
                pass

            selected.arm = bool(target_state)
            self.show_message("LinnStrument Arrangement: Track Arm %s" % ("ON" if selected.arm else "OFF"))
        except Exception as e:
            try:
                self.log_message("Arrangement track arm failed: %s" % e)
            except Exception:
                pass


    def _start_arrangement_arrow_repeat(self, command):
        try:
            if not hasattr(self, "_arrangement_held_arrows") or self._arrangement_held_arrows is None:
                self._arrangement_held_arrows = set()
            self._arrangement_held_arrows.add(str(command))
            self._send_arrangement_osc(str(command))
            if not bool(getattr(self, "_arrangement_arrow_repeat_active", False)):
                self._arrangement_arrow_repeat_active = True
                self.schedule_message(1 if self._shift else 2, self._repeat_arrangement_arrows)
        except Exception as e:
            try:
                self.log_message("Arrangement arrow repeat start failed: %s" % e)
            except Exception:
                pass

    def _stop_arrangement_arrow_repeat(self, command):
        try:
            if hasattr(self, "_arrangement_held_arrows") and self._arrangement_held_arrows is not None:
                self._arrangement_held_arrows.discard(str(command))
        except Exception:
            pass

    def _repeat_arrangement_arrows(self):
        try:
            held = list(getattr(self, "_arrangement_held_arrows", set()))
            if not held or not bool(getattr(self, "_arrangement_mode", False)):
                self._arrangement_arrow_repeat_active = False
                return
            for command in held:
                self._send_arrangement_osc(command)
            self.schedule_message(1 if self._shift else 2, self._repeat_arrangement_arrows)
        except Exception as e:
            self._arrangement_arrow_repeat_active = False
            try:
                self.log_message("Arrangement arrow repeat failed: %s" % e)
            except Exception:
                pass

    def _arrangement_hold_command_for_pad(self, column, row):
        # v1.49: Hold/repeat only for horizontal navigation.
        commands = {
            (14, 6): "arrow_left",   # N2
            (16, 6): "arrow_right",  # P2
        }
        return commands.get((int(column), int(row)), None)


    def _handle_arrangement_pad_release(self, column, row):
        try:
            # Physical active-track fader columns are handled before the
            # 128-to-200 logical column conversion.
            if int(column) in (14, 15, 16, 17, 19, 20):
                return self._arrangement_stop_active_track_fader(column)

            logical_column = self._arrangement_physical_to_logical_column_200(column)
            if logical_column is None:
                return True
            # H8/J8 remain on physical columns 8/10 on LinnStrument 200.
            if row == 0 and column in (8, 10):
                direction = "up" if column == 8 else "down"
                self._stop_track_zoom(direction)
                return True

            # LinnStrument 200 hardware mapping:
            # physical column 23 = logical N, physical column 25 = logical P.
            # Use the physical columns here because this method receives the
            # raw pad coordinate on Note Off.
            if row == 4 and column in (23, 25):
                released_pad = "N4" if column == 23 else "P4"
                self._scrub_debug("%s NOTE OFF" % released_pad)
                if self._scrub_pad_held == released_pad:
                    self._scrub_pad_held = None
                    self._scrub_repeat_active = False
                    self._scrub_y_value = 0
                return True
            command = self._arrangement_hold_command_for_pad(logical_column, row)
            if command:
                self._stop_arrangement_arrow_repeat(command)
                return True
        except Exception as e:
            try:
                self.log_message("Arrangement pad release failed: %s" % e)
            except Exception:
                pass
        return False


    def _arrangement_capture_midi(self):
        try:
            self._capture_midi()
            return True
        except Exception as e:
            try:
                self.log_message("Arrangement capture MIDI failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_back_to_arrangement(self):
        try:
            if self._trigger_back_to_arrangement():
                self.show_message("LinnStrument Arrangement: Back to Arrangement")
                return True
            self.show_message("LinnStrument Arrangement: Back to Arrangement unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement back to arrangement failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_set_locator(self):
        try:
            song = self.song()
            if hasattr(song, "set_or_delete_cue"):
                song.set_or_delete_cue()
                self.show_message("LinnStrument Arrangement: Set Locator")
                return True
            self.show_message("LinnStrument Arrangement: Set Locator unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement set locator failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_delete_locator(self):
        try:
            song = self.song()
            now = float(getattr(song, "current_song_time", 0.0))
            cue_points = list(getattr(song, "cue_points", []))
            best = None
            best_distance = 999999.0
            for cue in cue_points:
                try:
                    distance = abs(float(getattr(cue, "time", 999999.0)) - now)
                    if distance < best_distance:
                        best = cue
                        best_distance = distance
                except Exception:
                    pass

            if best is not None and best_distance < 0.08:
                for method_name in ("delete_cue", "delete"):
                    method = getattr(best, method_name, None)
                    if callable(method):
                        try:
                            method()
                            self.show_message("LinnStrument Arrangement: Delete Locator")
                            return True
                        except Exception:
                            pass

                # Fallback: Live's set_or_delete_cue toggles a cue at the current playhead.
                if hasattr(song, "set_or_delete_cue"):
                    song.set_or_delete_cue()
                    self.show_message("LinnStrument Arrangement: Delete Locator")
                    return True

            self.show_message("LinnStrument Arrangement: no locator at playhead")
        except Exception as e:
            try:
                self.log_message("Arrangement delete locator failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_next_locator(self):
        try:
            song = self.song()
            method = getattr(song, "jump_to_next_cue", None)
            if callable(method):
                method()
                self.show_message("LinnStrument Arrangement: Next Locator")
                return True
            self.show_message("LinnStrument Arrangement: Next Locator unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement next locator failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_previous_locator(self):
        try:
            song = self.song()
            method = getattr(song, "jump_to_prev_cue", None)
            if callable(method):
                method()
                self.show_message("LinnStrument Arrangement: Previous Locator")
                return True
            self.show_message("LinnStrument Arrangement: Previous Locator unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement previous locator failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_command_for_pad(self, column, row):
        # v1.52 Arrangement Mode 2.0 layout.
        # Coordinates: A=1..P=16, visual row 1 top = firmware row 7.
        # Direct API/mode functions are handled in _handle_arrangement_pad().
        commands = {
            # History

            # Edit / view / automation
            (4, 7): "rename",        # D1
            (4, 6): "loop",          # D2
            (4, 5): "follow_playback", # D3
            (6, 7): "automation",    # F1
            (6, 6): "draw_mode",     # F2
            (6, 5): "snap_grid",     # F3

            # Clip editing
            (8, 7): "split",         # H1
            (9, 7): "duplicate",     # I1
            (10, 7): "consolidate",  # J1
            (8, 6): "copy",          # H2
            (9, 6): "paste",         # I2
            (10, 6): "cut",          # J2
            (8, 5): "delete",        # H3
            (9, 5): "mute_clip",     # I3
            (10, 5): "reverse",      # J3

            # Zoom / fit
            (10, 3): "zoom_in",       # H5
            (8, 3): "zoom_out",     # J5
            (9, 3): "fit_width",     # I5
            (9, 2): "fit_height",    # I6
            (9, 1): "zoom_selection",# I7
            (9, 0): "zoom_back",     # I8

            # Navigation one-shot
            (15, 7): "arrow_up",     # O1
            (15, 5): "arrow_down",   # O3
        }
        return commands.get((int(column), int(row)), None)


    def _arrangement_toggle_automation_arm(self):
        try:
            song = self.song()
            for attr in ("automation_arm", "session_automation_record"):
                try:
                    if hasattr(song, attr):
                        current = bool(getattr(song, attr))
                        setattr(song, attr, not current)
                        self.show_message("LinnStrument Arrangement: Automation Arm %s" % ("ON" if not current else "OFF"))
                        return True
                except Exception:
                    pass
            self.show_message("LinnStrument Arrangement: Automation Arm unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement Automation Arm failed: %s" % e)
            except Exception:
                pass
        return False

    def _selected_track_is_midi_for_arrangement(self):
        try:
            track = self.song().view.selected_track
            if track is None:
                return False

            # Ableton Track usually exposes has_midi_input / has_audio_input.
            if bool(getattr(track, "has_midi_input", False)):
                return True

            # Fallback: an armable track without audio input is usually MIDI.
            if bool(getattr(track, "can_be_armed", False)) and not bool(getattr(track, "has_audio_input", False)):
                return True
        except Exception:
            pass
        return False

    def _arrangement_record_and_maybe_note_mode(self):
        try:
            is_midi_track = self._selected_track_is_midi_for_arrangement()
            self._arrangement_record()

            if is_midi_track:
                try:
                    self._note_return_mode = "arrangement"
                except Exception:
                    pass
                self.enter_note_mode()
                self.show_message("LinnStrument Arrangement: Record + Note Mode")
            return True
        except Exception as e:
            try:
                self.log_message("Arrangement record/note failed: %s" % e)
            except Exception:
                pass
            return False

    def _arrangement_toggle_midi_overdub(self):
        # Best-effort Live API toggle for MIDI Arrangement Overdub.
        # Different Live versions expose this under different property names.
        try:
            song = self.song()
            for attr in ("arrangement_overdub", "midi_arrangement_overdub", "overdub"):
                try:
                    if hasattr(song, attr):
                        current = bool(getattr(song, attr))
                        setattr(song, attr, not current)
                        self.show_message("LinnStrument Arrangement: MIDI Overdub %s" % ("ON" if not current else "OFF"))
                        return True
                except Exception:
                    pass
            self.show_message("LinnStrument Arrangement: MIDI Overdub unavailable")
        except Exception as e:
            try:
                self.log_message("Arrangement MIDI Overdub failed: %s" % e)
            except Exception:
                pass
        return False

    def _enter_note_mode_with_return(self, return_mode):
        try:
            self._note_return_mode = str(return_mode)
        except Exception:
            self._note_return_mode = "session"
        self.enter_note_mode()

    def _return_from_note_mode(self):
        # Arrangement_View refactor1:
        # Note Mode returns to Arrangement View, not Session View.
        return self.enter_arrangement_mode()


    def _enter_arrangement_from_session(self):
        try:
            if not bool(getattr(self, "_session_mode", False)):
                self.enter_session_mode()
            self.enter_arrangement_mode()
            return True
        except Exception as e:
            try:
                self.log_message("Enter Arrangement from Session failed: %s" % e)
            except Exception:
                pass
        return False

    # ------------------------------------------------------------------
    # v2.2.8 LinnStrument 200 active-track mixer block
    # ------------------------------------------------------------------
    def _arrangement_active_track_fader_kind(self, physical_column):
        return {
            14: ("send", 0),  # N = Send A
            15: ("send", 1),  # O = Send B
            16: ("send", 2),  # P = Send C
            17: ("send", 3),  # Q = Send D
            19: ("pan", None),  # S
            20: ("volume", None),  # T
        }.get(int(physical_column))

    def _arrangement_active_track_parameter(self, physical_column):
        try:
            track = self._selected_track_for_arrangement()
            if track is None:
                return None

            kind = self._arrangement_active_track_fader_kind(physical_column)
            if kind is None:
                return None

            parameter_type, send_index = kind
            mixer = getattr(track, "mixer_device", None)
            if mixer is None:
                return None

            if parameter_type == "volume":
                return getattr(mixer, "volume", None)
            if parameter_type == "pan":
                return getattr(mixer, "panning", None)
            if parameter_type == "send":
                sends = list(getattr(mixer, "sends", []))
                if send_index is not None and 0 <= int(send_index) < len(sends):
                    return sends[int(send_index)]
        except Exception:
            pass
        return None

    def _arrangement_parameter_normalized(self, parameter):
        try:
            minimum = float(getattr(parameter, "min", 0.0))
            maximum = float(getattr(parameter, "max", 1.0))
            value = float(getattr(parameter, "value", minimum))
            if maximum <= minimum:
                return 0.0
            return max(0.0, min(1.0, (value - minimum) / (maximum - minimum)))
        except Exception:
            return 0.0

    def _arrangement_set_parameter_normalized(self, parameter, normalized):
        try:
            normalized = max(0.0, min(1.0, float(normalized)))
            minimum = float(getattr(parameter, "min", 0.0))
            maximum = float(getattr(parameter, "max", 1.0))
            parameter.value = minimum + ((maximum - minimum) * normalized)
            return True
        except Exception:
            return False

    def _arrangement_active_track_color(self):
        try:
            index = self._selected_track_index()
            if index is not None and int(index) >= 0:
                return self._mixer_track_color(int(index))
        except Exception:
            pass
        return ColorMap.MIXER_ON

    def _arrangement_fader_band_from_row_y(self, row, y_value):
        """Return normalized 0..1 for an 8-row fader with per-pad Y fine control."""
        try:
            row = max(0, min(7, int(row)))
            y_value = max(0, min(127, int(y_value)))
        except Exception:
            row = 0
            y_value = 0
        low = float(row) / 8.0
        high = float(row + 1) / 8.0
        return low + ((high - low) * (float(y_value) / 127.0))

    def _arrangement_pan_from_row_y(self, row, y_value):
        """Linear pan mapping: bottom=-1, top=+1.

        Visual S1-S4 are right; S5-S8 are left.
        """
        normalized = self._arrangement_fader_band_from_row_y(row, y_value)
        return -1.0 + (2.0 * normalized)

    def _arrangement_redraw_single_active_track_fader(self, physical_column):
        """Immediate low-latency redraw of only the changed Active Track fader."""
        try:
            physical_column = int(physical_column)
            color = self._arrangement_active_track_color()
            parameter = self._arrangement_active_track_parameter(physical_column)
            kind = self._arrangement_active_track_fader_kind(physical_column)
            if parameter is None or kind is None:
                return

            if kind[0] == "pan":
                pan_value = float(getattr(parameter, "value", 0.0))
                self._draw_arrangement_pan_fader(physical_column, pan_value, color)
            else:
                normalized = self._arrangement_parameter_normalized(parameter)
                self._draw_arrangement_linear_fader(physical_column, normalized, color)
        except Exception as e:
            try:
                self.log_message("Arrangement single-fader redraw failed: %s" % e)
            except Exception:
                pass

    def _arrangement_set_active_track_fader_from_y(self, physical_column, row, y_value):
        try:
            parameter = self._arrangement_active_track_parameter(physical_column)
            kind = self._arrangement_active_track_fader_kind(physical_column)
            if parameter is None or kind is None:
                return False

            if kind[0] == "pan":
                pan_value = self._arrangement_pan_from_row_y(row, y_value)
                minimum = float(getattr(parameter, "min", -1.0))
                maximum = float(getattr(parameter, "max", 1.0))
                parameter.value = max(minimum, min(maximum, pan_value))
            else:
                normalized = self._arrangement_fader_band_from_row_y(row, y_value)
                self._arrangement_set_parameter_normalized(parameter, normalized)

            self._arrangement_redraw_single_active_track_fader(physical_column)
            return True
        except Exception as e:
            try:
                self.log_message("Arrangement active-track Y fader failed: %s" % e)
            except Exception:
                pass
        return False

    def _arrangement_start_active_track_fader(self, physical_column, row):
        # All faders are Shift-protected.
        if not bool(getattr(self, "_shift", False)):
            return True

        try:
            physical_column = int(physical_column)
            row = max(0, min(7, int(row)))
            parameter = self._arrangement_active_track_parameter(physical_column)
            kind = self._arrangement_active_track_fader_kind(physical_column)
            if parameter is None or kind is None:
                self.show_message("LinnStrument Arrangement: parameter unavailable")
                return True

            self._arrangement_active_faders[physical_column] = row

            # Coarse row selection on initial press; Y then provides fine adjustment.
            if kind[0] == "pan":
                pan_value = self._arrangement_pan_from_row_y(row, 64)
                minimum = float(getattr(parameter, "min", -1.0))
                maximum = float(getattr(parameter, "max", 1.0))
                parameter.value = max(minimum, min(maximum, pan_value))
                self.show_message("LinnStrument Arrangement: Active Track Pan")
            else:
                normalized = self._arrangement_fader_band_from_row_y(row, 64)
                self._arrangement_set_parameter_normalized(parameter, normalized)
                if kind[0] == "volume":
                    self.show_message("LinnStrument Arrangement: Active Track Volume")
                else:
                    self.show_message(
                        "LinnStrument Arrangement: Active Track Send %s"
                        % ("ABCD"[int(kind[1])])
                    )

            self._arrangement_redraw_single_active_track_fader(physical_column)
        except Exception as e:
            try:
                self.log_message("Arrangement active-track fader press failed: %s" % e)
            except Exception:
                pass
        return True

    def _arrangement_stop_active_track_fader(self, physical_column):
        try:
            # Keep the active fader latched across brief Note-Off events so Y fine control remains continuous.
            pass
        except Exception:
            pass
        return True

    def _arrangement_clear_active_track_faders(self):
        try:
            self._arrangement_active_faders.clear()
        except Exception:
            self._arrangement_active_faders = {}

    def _arrangement_set_selected_track_monitor(self, state_value, label):
        try:
            track = self._selected_track_for_arrangement()
            if track is None or not hasattr(track, "current_monitoring_state"):
                self.show_message("LinnStrument Arrangement: Monitor unavailable")
                return True

            track.current_monitoring_state = int(state_value)
            self.show_message("LinnStrument Arrangement: Monitor %s" % str(label))
            self._draw_arrangement_active_track_mixer()
        except Exception as e:
            try:
                self.log_message("Arrangement monitor state failed: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument Arrangement: Monitor unavailable")
        return True

    def _draw_arrangement_linear_fader(self, physical_column, normalized, color):
        try:
            normalized = max(0.0, min(1.0, float(normalized)))
            current_row = max(-1, min(7, int(round((normalized * 8.0) - 1.0))))
            for row in range(8):
                self._set_pad_color(
                    int(physical_column),
                    row,
                    color if row <= current_row else LSColor.OFF,
                )
        except Exception:
            pass

    def _draw_arrangement_pan_fader(self, physical_column, pan_value, color):
        """Differential pan LED update.

        Never clears and redraws the complete column. Each pad is updated only
        when its requested color differs from the last color sent to the
        LinnStrument. This removes visible OFF/ON flicker.
        """
        try:
            physical_column = int(physical_column)
            pan_value = max(-1.0, min(1.0, float(pan_value)))

            desired = [LSColor.OFF] * 8

            if abs(pan_value) < 0.04:
                desired[3] = color
                desired[4] = color
            elif pan_value > 0.0:
                count = max(1, min(4, int(round(pan_value * 4.0))))
                for row in range(4, 4 + count):
                    desired[row] = color
            else:
                count = max(1, min(4, int(round(abs(pan_value) * 4.0))))
                for row in range(3, 3 - count, -1):
                    desired[row] = color

            cache = getattr(self, "_arrangement_pan_led_states", None)
            if not isinstance(cache, dict):
                cache = {}
                self._arrangement_pan_led_states = cache

            for row, requested_color in enumerate(desired):
                key = (physical_column, row)
                if cache.get(key) != requested_color:
                    self._set_pad_color(physical_column, row, requested_color)
                    cache[key] = requested_color

        except Exception as e:
            try:
                self.log_message("Arrangement pan LED differential draw failed: %s" % e)
            except Exception:
                pass


    def _draw_arrangement_active_track_mixer(self):
        try:
            color = self._arrangement_active_track_color()

            # Sends D/C/B/A and Volume.
            for physical_column in (14, 15, 16, 17, 20):
                parameter = self._arrangement_active_track_parameter(physical_column)
                normalized = self._arrangement_parameter_normalized(parameter) if parameter is not None else 0.0
                self._draw_arrangement_linear_fader(physical_column, normalized, color)

            # Pan.
            pan_parameter = self._arrangement_active_track_parameter(19)
            pan_value = float(getattr(pan_parameter, "value", 0.0)) if pan_parameter is not None else 0.0
            self._draw_arrangement_pan_fader(19, pan_value, color)

            # Monitor controls V6/V7/V8.
            self._set_pad_color(22, 2, LSColor.CYAN)    # V6 In
            self._set_pad_color(22, 1, LSColor.ORANGE)  # V7 Auto
            self._set_pad_color(22, 0, LSColor.ORANGE)  # V8 Off
        except Exception as e:
            try:
                self.log_message("Arrangement active-track mixer draw failed: %s" % e)
            except Exception:
                pass


    def _arrangement_fast_redraw_active_track_mixer(self):
        """Immediate full redraw for mode/track changes without queued redraw backlog."""
        self._draw_arrangement_active_track_mixer()

    def _arrangement_physical_to_logical_column_200(self, column):
        # LinnStrument_200 Arrangement_View v1.0.3-refactor2b:
        # Arrangement right block from the 128 layout is moved:
        # logical 14/15/16 -> physical 23/24/25.
        # Physical 14/15/16 are intentionally empty in Arrangement Mode.
        try:
            column = int(column)
            if column in (14, 15, 16):
                return None
            if column in (23, 24, 25):
                return column - 9
            return column
        except Exception:
            return None

    def _arrangement_logical_to_physical_column_200(self, column):
        try:
            column = int(column)
            if column in (14, 15, 16):
                return column + 9
            return column
        except Exception:
            return column

    def _arrangement_shift_pad_for(self, column, row):
        # LinnStrument_200:
        # Physical 25/row0 = logical P8 Shift
        # Physical 24/row6 = logical O2 Turbo Shift
        try:
            logical_column = self._arrangement_physical_to_logical_column_200(column)
            if logical_column is None:
                return False
            row = int(row)
            return (logical_column == 16 and row == 0) or (logical_column == 15 and row == 6)
        except Exception:
            return False


    def _handle_arrangement_pad(self, column, row):
        try:
            # v2.2.8 physical-only active-track mixer block.
            # All faders require Shift (Y8).
            if int(column) in (14, 15, 16, 17, 19, 20):
                return self._arrangement_start_active_track_fader(column, row)

            # V6/V7/V8 monitor mode.
            if int(column) == 22 and int(row) == 2:
                return self._arrangement_set_selected_track_monitor(0, "In")
            if int(column) == 22 and int(row) == 1:
                return self._arrangement_set_selected_track_monitor(1, "Auto")
            if int(column) == 22 and int(row) == 0:
                return self._arrangement_set_selected_track_monitor(2, "Off")

            logical_column = self._arrangement_physical_to_logical_column_200(column)
            if logical_column is None:
                return True
            column = logical_column
            row = int(row)

            if (column == 16 and row == 0) or (column == 15 and row == 6):  # P8/O2 Shift, logical columns
                self._shift = True
                self._draw_arrangement_mode_leds()
                self.show_message("LinnStrument Arrangement: Shift ON")
                return True

            hold_command = self._arrangement_hold_command_for_pad(column, row)
            if hold_command:
                self._start_arrangement_arrow_repeat(hold_command)
                return True

            # D6/D7/D8: global Launch Quantization.
            if column == 4 and row == 2:  # D6: None
                self._set_arrangement_launch_quantization(
                    "None",
                    ("q_no_q", "q_none", "q_no_quantization"),
                    fallback_value=0,
                )
                return True

            if column == 4 and row == 1:  # D7: 1/16
                self._set_arrangement_launch_quantization(
                    "1/16",
                    ("q_sixtenth", "q_sixteenth", "q_1_16"),
                    fallback_value=11,
                )
                return True

            if column == 4 and row == 0:  # D8: 1 Bar
                self._set_arrangement_launch_quantization(
                    "1 Bar",
                    ("q_bar", "q_1_bar"),
                    fallback_value=4,
                )
                return True

            # L6/L7/L8: tempo functions are active only while Shift is held.
            if column == 12 and row == 2:  # L6: +1 BPM
                if self._shift:
                    self._change_tempo(1.0)
                return True

            if column == 12 and row == 1:  # L7: -1 BPM
                if self._shift:
                    self._change_tempo(-1.0)
                return True

            if column == 12 and row == 0:  # L8: Tap Tempo
                if self._shift:
                    self._arrangement_tap_tempo()
                return True

            # F8: Fold / Unfold all tracks (Option+U).
            if row == 0 and column == 6:
                self._send_arrangement_osc("fold_all_tracks")
                self.show_message("LinnStrument Arrangement: Fold / Unfold All Tracks")
                return True

            # H8/J8: vertical zoom of active track, repeated while held.
            if row == 0 and column in (8, 10):
                direction = "up" if column == 8 else "down"
                self._start_track_zoom(direction)
                self.show_message(
                    "LinnStrument Arrangement: Track Height %s"
                    % ("Increase" if direction == "up" else "Decrease")
                )
                return True

            # N4/P4: dedicated timeline scrub pads; Y controls speed.
            if row == 4 and column in (14, 16):
                self._scrub_pad_held = "N4" if column == 14 else "P4"
                self._scrub_y_value = 0
                self._scrub_debug("%s NOTE ON" % self._scrub_pad_held)
                if not self._scrub_repeat_active:
                    self._scrub_repeat_active = True
                    self.schedule_message(1, self._scrub_tick)
                self.show_message("LinnStrument Arrangement: %s Y Scrub" % self._scrub_pad_held)
                return True

            # Direct mode changes
            if column == 1 and row == 0:    # A8: Note Mode. Shift+A8 disabled.
                if self._shift:
                    return True
                self.enter_note_mode()
                return True

            if column == 1 and row == 7:    # A1 Undo / Shift+Redo
                command = "redo" if self._shift else "undo"
                self._send_arrangement_osc(command)
                self.show_message("LinnStrument Arrangement: %s" % command)
                return True
            if column == 2 and row == 1:    # B7 Automation Arm
                self._arrangement_toggle_automation_arm()
                return True

            # Direct API functions
            if column == 1 and row == 3:    # A5 Metronome
                self._arrangement_toggle_metronome()
                return True
            if column == 1 and row == 2:    # A6 Play/Stop
                self._arrangement_play_stop()
                return True
            if column == 2 and row == 2:    # B6 Continue Play
                self._arrangement_continue_play()
                return True
            if column == 1 and row == 1:    # A7 Arrangement Record / MIDI Track -> Note Mode
                self._arrangement_record_and_maybe_note_mode()
                return True
            if column == 6 and row == 4:    # F4 Back to Arrangement
                if not self._arrangement_back_to_arrangement():
                    self._send_arrangement_osc("back_to_arrangement")
                return True

            if column == 4 and row == 4:    # D4 MIDI Overdub Arrangement
                self._arrangement_toggle_midi_overdub()
                return True

            # Locator API
            if column == 12 and row == 7:   # L1 Set Locator
                self._arrangement_set_locator()
                return True
            if column == 12 and row == 6:   # L2 Delete Locator
                self._arrangement_delete_locator()
                return True
            if column == 12 and row == 5:   # L3 Next Locator
                self._arrangement_next_locator()
                return True
            if column == 12 and row == 4:   # L4 Previous Locator
                self._arrangement_previous_locator()
                return True

            # Selected track API
            if column == 15 and row == 2:   # O6 Track Mute
                self._arrangement_toggle_selected_track_mute()
                return True
            if column == 15 and row == 1:   # O7 Track Solo
                self._arrangement_toggle_selected_track_solo()
                return True
            if column == 15 and row == 0:   # O8 Track Arm, exclusive
                self._arrangement_toggle_selected_track_arm()
                return True

            command = self._arrangement_command_for_pad(column, row)
            if command:
                self._send_arrangement_osc(command)
                self.show_message("LinnStrument Arrangement: %s" % command)
                return True
        except Exception as e:
            try:
                self.log_message("Arrangement pad handling failed: %s" % e)
            except Exception:
                pass
        return False


    def enter_arrangement_mode(self):
        # v1.38: Separate Arrangement Mode, independent from Session grid.
        try:
            self._arrangement_mode = True
            self._session_mode = False
            self._mixer_mode = False
            self._delete_mode = False
            self._copy_mode = False
            self._shift = False
            self._allow_control_exit = True
            self._update_counter = 0

            # Keep User Firmware Mode ON for stable pad coordinates.
            self._send_nrpn(USER_MODE_NRPN, 1, channel=0)
            self._send_nrpn(USER_MODE_NRPN, 1, channel=15)
            self._set_user_mode_expression(y_enabled=True, z_enabled=False)
            self._scrub_pad_held = None
            self._scrub_repeat_active = False
            self._scrub_y_value = 0
            self._track_zoom_held = None
            self._track_zoom_repeat_active = False

            self.show_message("LinnStrument: Arrangement Mode")
            self.log_message("LinnStrument: Arrangement Mode")
        except Exception as e:
            try:
                self.log_message("enter_arrangement_mode state failed: %s" % e)
            except Exception:
                pass

        try:
            self._draw_arrangement_mode_leds()
        except Exception as e:
            try:
                self.log_message("enter_arrangement_mode draw failed: %s" % e)
            except Exception:
                pass

    def exit_arrangement_mode(self):
        # Arrangement_View refactor1:
        # There is no Session View target in this branch.
        return self.enter_arrangement_mode()


    def _draw_arrangement_mode_leds(self):
        try:
            # Full clear: Arrangement Mode is visually separate from Session Mode.
            for column in range(1, 25 + 1):
                for row in range(0, 8):
                    self._set_pad_color(column, row, ColorMap.EMPTY)

            pads = [
                (1, 7, LSColor.WHITE),
                (1, 3, LSColor.ORANGE),
                (1, 2, LSColor.GREEN),
                (2, 2, LSColor.GREEN),
                (1, 1, LSColor.RED),
                (2, 1, LSColor.RED),
                (1, 0, LSColor.WHITE),
                (4, 7, LSColor.MAGENTA),
                (4, 6, LSColor.YELLOW),
                (4, 5, LSColor.GREEN),
                (4, 4, LSColor.RED),
                (4, 2, LSColor.YELLOW),
                (4, 1, LSColor.YELLOW),
                (4, 0, LSColor.YELLOW),
                (6, 7, LSColor.ORANGE),
                (6, 6, LSColor.BLUE),
                (6, 5, LSColor.CYAN),
                (6, 4, LSColor.MAGENTA),
                (8, 7, LSColor.RED),
                (9, 7, LSColor.ORANGE),
                (10, 7, LSColor.YELLOW),
                (8, 6, LSColor.ORANGE),
                (9, 6, LSColor.YELLOW),
                (10, 6, LSColor.RED),
                (8, 5, LSColor.RED),
                (9, 5, LSColor.ORANGE),
                (10, 5, LSColor.YELLOW),
                (9, 3, LSColor.CYAN),
                (9, 2, LSColor.CYAN),
                (9, 1, LSColor.BLUE),
                (9, 0, LSColor.BLUE),
                (8, 3, LSColor.BLUE),
                (6, 0, LSColor.CYAN),   # F8 Fold / Unfold all tracks
                (8, 0, LSColor.CYAN),   # H8 increase active-track height
                (10, 0, LSColor.CYAN),  # J8 decrease active-track height
                (10, 3, LSColor.BLUE),
                (12, 7, LSColor.GREEN),
                (12, 6, LSColor.RED),
                (12, 5, LSColor.GREEN),
                (12, 4, LSColor.GREEN),
                (12, 2, LSColor.ORANGE),
                (12, 1, LSColor.ORANGE),
                (12, 0, LSColor.ORANGE),
                (15, 7, LSColor.GREEN),
                (15, 6, LSColor.WHITE),
                (15, 5, LSColor.GREEN),
                (14, 6, LSColor.GREEN),
                (16, 6, LSColor.GREEN),
                (15, 2, LSColor.ORANGE),
                (15, 1, LSColor.BLUE),
                (15, 0, LSColor.RED),
                (16, 0, LSColor.WHITE),
            ]
            pads.extend([
                (14, 4, LSColor.CYAN),
                (16, 4, LSColor.CYAN),
            ])
            for column, row, color in pads:
                self._set_pad_color(self._arrangement_logical_to_physical_column_200(column), row, color)
            # LinnStrument_200: clear physical 14-16, because logical 14-16 live at 23-25.
            for clear_col in (14, 15, 16):
                for clear_row in range(8):
                    self._set_pad_color(clear_col, clear_row, LSColor.OFF)

            # Physical N–V active-track mixer block is drawn last.
            self._draw_arrangement_active_track_mixer()

        except Exception as e:
            try:
                self.log_message("draw_arrangement_mode_leds failed: %s" % e)
            except Exception:
                pass


    def _handle_fixed_length_column(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _toggle_fixed_length(self, bars):
        if self._fixed_length_bars == int(bars):
            self._fixed_length_bars = 0
            self.show_message("LinnStrument: Fixed Length OFF")
        else:
            self._fixed_length_bars = int(bars)
            self.show_message("LinnStrument: Fixed Length %d bar%s" % (int(bars), "" if int(bars) == 1 else "s"))
        self._draw_session_leds()

    def _draw_fixed_length_column(self, *args, **kwargs):
        # Arrangement_View refactor2: disabled Session-only helper.
        return


    def _fixed_length_color(self, bars):
        # v3.10.71: Fixed Length Recording pads use LinnStrument light blue / cyan.
        if self._fixed_length_bars == int(bars):
            return self._blink_color(ColorMap.LIGHT_BLUE)
        return ColorMap.LIGHT_BLUE


    def _start_fixed_length_watch(self, slot, bars):
        self._fixed_length_slot = slot
        self._fixed_length_start_beats = self._song_time_in_beats()
        numerator = int(getattr(self.song(), "signature_numerator", 4) or 4)
        self._fixed_length_target_beats = float(int(bars) * numerator)
        self._fixed_length_seen_recording = False
        try:
            self.log_message("Fixed Length watch started: %s bars" % bars)
        except Exception:
            pass

    def _update_fixed_length_recording(self):
        if self._fixed_length_slot is None:
            return

        try:
            slot = self._fixed_length_slot
            clip = getattr(slot, "clip", None)

            is_recording = self._safe_bool(slot, "is_recording")
            if clip is not None:
                is_recording = is_recording or self._safe_bool(clip, "is_recording")

            if is_recording:
                self._fixed_length_seen_recording = True

            # If recording never starts or has already stopped, clear once it is safe.
            if not is_recording and self._fixed_length_seen_recording:
                self._clear_fixed_length_watch()
                return

            if not self._fixed_length_seen_recording:
                return

            start = self._fixed_length_start_beats
            target = self._fixed_length_target_beats
            now = self._song_time_in_beats()

            if start is not None and target is not None and now is not None and now >= start + target:
                slot.fire()
                self.show_message("LinnStrument: Fixed Length complete")
                self._clear_fixed_length_watch()
        except Exception as e:
            try:
                self.log_message("Fixed Length update failed: %s" % e)
            except Exception:
                pass
            self._clear_fixed_length_watch()

    def _clear_fixed_length_watch(self):
        self._fixed_length_slot = None
        self._fixed_length_start_beats = None
        self._fixed_length_target_beats = None
        self._fixed_length_seen_recording = False

    def _song_time_in_beats(self):
        try:
            time = str(self.song().get_current_beats_song_time())
            parts = [int(p) for p in time.split(".")]
            bar = parts[0] if len(parts) > 0 else 1
            beat = parts[1] if len(parts) > 1 else 1
            sub = parts[2] if len(parts) > 2 else 0
            numerator = int(getattr(self.song(), "signature_numerator", 4) or 4)
            return float((bar - 1) * numerator) + float(beat - 1) + (float(sub) / 100.0)
        except Exception:
            return None

    def _fixed_length_launch_blocked(self, track_index, scene_index):
        # v1.0: preflight check used before deciding auto-switch to Note Mode.
        # If Fixed Length recording would be started from stopped transport, block
        # the entire action so the warning message is not overwritten by "Note Mode".
        try:
            if self._fixed_length_bars <= 0:
                return False
            tracks = self._tracks()
            if track_index >= len(tracks):
                return False
            track = tracks[track_index]
            if scene_index >= len(track.clip_slots):
                return False
            slot = track.clip_slots[scene_index]
            if self._safe_bool(slot, "has_clip"):
                return False
            armed = bool(getattr(track, "arm", False)) or bool(getattr(track, "implicit_arm", False))
            if not armed:
                return False
            if not bool(self.song().is_playing):
                self.show_message("LinnStrument: Start Play first for Fixed Length")
                return True
        except Exception:
            pass
        return False

    def _launch_clip(self, track_index, scene_index):
        # Arrangement_View refactor2: clip launch disabled.
        return


    def _delete_clip(self, track_index, scene_index):
        tracks = self._tracks()
        if track_index >= len(tracks):
            return
        if scene_index >= len(tracks[track_index].clip_slots):
            return
        slot = tracks[track_index].clip_slots[scene_index]
        try:
            if self._safe_bool(slot, "has_clip"):
                slot.delete_clip()
        except Exception as e:
            try:
                self.log_message("Could not delete clip: %s" % e)
            except Exception:
                pass

    def _launch_scene(self, scene_index):
        # Arrangement_View refactor2: scene launch disabled.
        return


    def _delete_scene(self, scene_index):
        try:
            scene_count = len(self.song().scenes)
            if scene_index < 0 or scene_index >= scene_count:
                return
            if scene_count <= 1:
                self.show_message("LinnStrument: cannot delete last scene")
                return

            self.song().delete_scene(scene_index)

            max_offset = max(0, len(self.song().scenes) - 7)
            self._scene_offset = min(self._scene_offset, max_offset)
            self._set_session_highlight()
            self.show_message("LinnStrument: scene deleted")
        except Exception as e:
            try:
                self.log_message("Could not delete scene: %s" % e)
            except Exception:
                pass
            self.show_message("LinnStrument: scene delete failed")

    def _stop_track_clips(self, track_index):
        try:
            tracks = self._tracks()
            if track_index >= len(tracks):
                return
            track = tracks[track_index]

            if hasattr(track, "stop_all_clips"):
                track.stop_all_clips()
                self.show_message("LinnStrument: stop track %d" % (track_index + 1))
                return

            for slot in list(track.clip_slots):
                try:
                    if self._safe_bool(slot, "is_playing") or self._safe_bool(slot, "is_recording"):
                        slot.stop()
                except Exception:
                    pass
            self.show_message("LinnStrument: stop track %d" % (track_index + 1))
        except Exception as e:
            try:
                self.log_message("Stop track clips failed: %s" % e)
            except Exception:
                pass

    def _toggle_track_active(self, track_index):
        tracks = self._tracks()
        if track_index < len(tracks):
            tracks[track_index].mute = not tracks[track_index].mute

    def _toggle_solo(self, track_index):
        tracks = self._tracks()
        if track_index < len(tracks):
            tracks[track_index].solo = not tracks[track_index].solo

    def _toggle_arm_exclusive_and_select(self, track_index):
        tracks = self._tracks()
        if track_index >= len(tracks):
            return

        selected_track = tracks[track_index]
        try:
            self.song().view.selected_track = selected_track
        except Exception:
            pass

        if not getattr(selected_track, "can_be_armed", False):
            return

        was_armed = bool(selected_track.arm)

        for track in tracks:
            if track != selected_track and getattr(track, "can_be_armed", False):
                try:
                    track.arm = False
                except Exception:
                    pass

        selected_track.arm = not was_armed

    def _toggle_metronome(self):
        try:
            song = self.song()
            song.metronome = not song.metronome
        except Exception:
            pass

    def _tracks(self):
        try:
            return list(self.song().visible_tracks)
        except Exception:
            return list(self.song().tracks)

    def _draw_session_leds(self):
        # Arrangement_View refactor2:
        # Session LED renderer is disabled. Arrangement LEDs are drawn by _draw_arrangement_mode_leds().
        return


    def _blink_color(self, color):
        return color if self._blink_on else ColorMap.EMPTY

    def _metronome_button_color(self):
        # v1.14:
        # Explicit orange/off blink. This prevents the Note Mode function pad
        # from falling back to a LinnStrument/default light-blue color during blink-off.
        try:
            if bool(self.song().metronome):
                return ColorMap.METRONOME_ON if self._blink_on else ColorMap.EMPTY
        except Exception:
            pass
        return ColorMap.METRONOME_ON


    def _play_blink_color(self):
        # v1.12: Explicit green/off blink for transport playing.
        # Avoid using any fallback/white color during blink-off.
        try:
            return ColorMap.PLAY_ON if self._blink_on else ColorMap.EMPTY
        except Exception:
            return ColorMap.EMPTY

    def _play_stop_button_color(self):
        # Arrangement_View v1.0.3-refactor2b: Play/Stop is always green.
        # Playing = blinking green; stopped = steady green.
        try:
            if bool(getattr(self.song(), "is_playing", False)):
                return LSColor.GREEN if bool(getattr(self, "_blink_on", True)) else LSColor.OFF
        except Exception:
            pass
        return LSColor.GREEN


    def _delete_mode_button_color(self):
        return self._blink_color(ColorMap.DELETE_MODE_ON) if self._delete_mode else ColorMap.DELETE_MODE_ON

    def _session_record_button_color(self):
        try:
            song = self.song()
            if self._arrangement_view_is_visible():
                if bool(getattr(song, "record_mode", False)):
                    return self._blink_color(ColorMap.SESSION_RECORD_ON)
                if self._back_to_arrangement_active():
                    return self._blink_color(ColorMap.METRONOME_ON)
                return ColorMap.SESSION_RECORD_ON

            if bool(getattr(song, "session_record", False)) or bool(getattr(song, "overdub", False)):
                return self._blink_color(ColorMap.SESSION_RECORD_ON)
        except Exception:
            pass
        return ColorMap.SESSION_RECORD_ON


    def _shift_button_color(self):
        return self._blink_color(ColorMap.WHITE) if self._shift else ColorMap.WHITE

    def _draw_function_column(self):
        self._set_pad_color(FUNCTION_COLUMN, UNDO_ROW, ColorMap.REDO if self._shift else ColorMap.UNDO)
        self._set_pad_color(FUNCTION_COLUMN, DUPLICATE_CLIP_ROW, self._copy_scene_mode_button_color())
        self._set_pad_color(FUNCTION_COLUMN, CAPTURE_SCENE_ROW, ColorMap.CAPTURE_SCENE)
        self._set_pad_color(FUNCTION_COLUMN, DELETE_MODE_ROW, self._delete_mode_button_color())
        self._set_pad_color(FUNCTION_COLUMN, METRONOME_ROW_FUNCTION, self._launch_quantization_shift_color() if self._shift else self._metronome_button_color())
        self._set_pad_color(FUNCTION_COLUMN, PLAY_STOP_ROW, self._play_stop_button_color())
        self._set_pad_color(FUNCTION_COLUMN, SESSION_RECORD_ROW, self._session_record_button_color())
        self._set_pad_color(FUNCTION_COLUMN, NOTE_MODE_ROW, ColorMap.WHITE)

    def _session_record_color(self):
        try:
            song = self.song()
            if bool(getattr(song, "session_record", False)) or bool(getattr(song, "overdub", False)):
                return ColorMap.SESSION_RECORD_ON
        except Exception:
            pass
        return ColorMap.NAV

    def _play_stop_color(self):
        try:
            return ColorMap.PLAY_ON if bool(self.song().is_playing) else ColorMap.PLAY_OFF
        except Exception:
            return ColorMap.PLAY_OFF

    def _track_fixed_clip_color(self, track_index):
        tracks = self._tracks()
        try:
            if track_index < len(tracks):
                color_value = int(getattr(tracks[track_index], "color"))
                color = self._closest_linnstrument_color(color_value)
                if color != ColorMap.EMPTY:
                    return color
        except Exception:
            pass

        visible_index = track_index - self._track_offset
        if visible_index < 0:
            visible_index = track_index
        return TRACK_CLIP_COLORS[visible_index % len(TRACK_CLIP_COLORS)]

    def _closest_linnstrument_color(self, ableton_color):
        rgb = self._ableton_color_to_rgb(ableton_color)
        if rgb is None:
            return ColorMap.EMPTY

        r, g, b = rgb
        best_color = ColorMap.EMPTY
        best_distance = None

        for color, ref in LS_RGB.items():
            rr, gg, bb = ref
            distance = ((r - rr) * (r - rr)) + ((g - gg) * (g - gg)) + ((b - bb) * (b - bb))
            if best_distance is None or distance < best_distance:
                best_distance = distance
                best_color = color

        return best_color

    def _ableton_color_to_rgb(self, color_value):
        try:
            value = int(color_value)
            r = (value >> 16) & 0xFF
            g = (value >> 8) & 0xFF
            b = value & 0xFF
            return (r, g, b)
        except Exception:
            return None

    def _clip_color(self, track_index, scene_index):
        return LSColor.OFF


    def _scene_color(self, scene_index):
        return LSColor.OFF


    def _track_active_color(self, track_index):
        tracks = self._tracks()
        if track_index >= len(tracks):
            return ColorMap.EMPTY
        return ColorMap.TRACK_ACTIVE_ON if not bool(getattr(tracks[track_index], "mute", False)) else ColorMap.EMPTY

    def _track_bool_color(self, track_index, attr, on_color, requires_armable=False):
        tracks = self._tracks()
        if track_index >= len(tracks):
            return ColorMap.EMPTY
        track = tracks[track_index]
        if requires_armable and not getattr(track, "can_be_armed", False):
            return ColorMap.EMPTY
        return on_color if bool(getattr(track, attr, False)) else ColorMap.EMPTY

    def _metronome_color(self):
        try:
            return ColorMap.METRONOME_ON if bool(self.song().metronome) else ColorMap.NAV
        except Exception:
            return ColorMap.NAV

    def _safe_bool(self, obj, attr):
        try:
            return bool(getattr(obj, attr))
        except Exception:
            return False

    def _set_pad_color(self, column, row, color):
        # v3.10.43-fw234-ch1-led-reference: LED CC20/21/22 are sent only on MIDI channel 1, reference build
        try:
            column = int(column)
            row = int(row)
            color = int(color)
            for status in (0xb0,):
                self._send_midi((status, 20, column))
                self._send_midi((status, 21, row))
                self._send_midi((status, 22, color))
        except Exception as e:
            try:
                self.log_message("Set pad color failed: %s" % e)
            except Exception:
                pass


    def _send_nrpn(self, parameter, value, channel=0):
        status = 0xB0 | channel
        parameter = int(parameter) & 0x3FFF
        value = int(value) & 0x3FFF
        self._send_midi((status, 99, (parameter >> 7) & 0x7F))
        self._send_midi((status, 98, parameter & 0x7F))
        self._send_midi((status, 6, (value >> 7) & 0x7F))
        self._send_midi((status, 38, value & 0x7F))
        self._send_midi((status, 101, 127))
        self._send_midi((status, 100, 127))
