LinnStrument 200 Arrangement View v2.2.5

New layout:
- F8: Fold / Unfold all tracks (Option+U), cyan
- H8: Increase active-track height while held, cyan
- J8: Decrease active-track height while held, cyan

Previous H6/J6 zoom assignments were removed.
N4/P4 scrub remains unchanged.
Requires LinnStrument Companion v2.2.5.
