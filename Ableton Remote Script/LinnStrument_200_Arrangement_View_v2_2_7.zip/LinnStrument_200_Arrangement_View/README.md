# LinnStrument_200_Arrangement_View v1.0.3-refactor2b

Based on stable v1.0.1-refactor2.

Only change:
- In Note Mode, A2 and A4 are ignored.
- No LED changes.
- No changes to Arrangement Mode, build_midi_map, User Firmware Mode, MIDI routing, LED engine, or Companion/OSC.
