LinnStrument 200 Arrangement View v2.2.4

New:
- H6: increase active-track height while held
- J6: decrease active-track height while held
- H6/J6 are blue

Hardware mapping:
- H/J remain physical columns 8/10 on LinnStrument 200
- Note On and Note Off use the 200-specific mapping path

Existing N4/P4 scrub remains unchanged.
Requires Companion v2.2.4 with track zoom support.
