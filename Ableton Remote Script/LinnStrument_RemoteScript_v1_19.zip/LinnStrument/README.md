# LinnStrument Ableton Remote Script v1.19

Based on LinnStrument v1.18.

Copy safety fix:
- Copy Clip now only copies into an empty target clip slot.
- Copy Scene now only copies into a completely empty target scene.
- If the target is not empty, the copy action is cancelled and a status message is shown:
  - "target slot not empty"
  - "target scene not empty"

Retained:
- Pad 2: Copy Clip Mode
- Shift + Pad 2: Copy Scene Mode
- Shift + Pad 3: Quantize active MIDI Clip to 1/16
- Shift + Pad 4: Delete Scene
- Unified LinnStrument 128 / 200 auto-detect.
