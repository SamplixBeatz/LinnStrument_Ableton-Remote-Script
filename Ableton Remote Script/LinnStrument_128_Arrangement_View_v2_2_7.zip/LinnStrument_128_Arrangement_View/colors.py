from __future__ import absolute_import, print_function, unicode_literals

class LSColor(object):
    OFF = 0
    RED = 1
    YELLOW = 2
    GREEN = 3
    CYAN = 4
    BLUE = 5
    MAGENTA = 6
    BLACK = 7
    WHITE = 8
    ORANGE = 9
    LIME = 10
    PINK = 11

class ColorMap(object):
    EMPTY = LSColor.OFF
    TRIGGERED = LSColor.YELLOW
    RECORDING = LSColor.RED
    SCENE_HAS_CLIPS = LSColor.WHITE
    SCENE_PLAYING = LSColor.LIME

    TRACK_ACTIVE_ON = LSColor.ORANGE
    SOLO_ON = LSColor.BLUE
    ARM_ON = LSColor.RED

    SESSION_RECORD_ON = LSColor.RED
    METRONOME_ON = LSColor.ORANGE
    NAV = LSColor.CYAN
    DELETE_MODE_ON = LSColor.RED
    DELETE_MODE_OFF = LSColor.MAGENTA

    UNDO = LSColor.WHITE
    REDO = LSColor.WHITE
    DUPLICATE_CLIP = LSColor.ORANGE
    CAPTURE_SCENE = LSColor.LIME
    PLAY_ON = LSColor.GREEN
    PLAY_OFF = LSColor.BLUE
    MIXER_ON = LSColor.CYAN
    MIXER_OFF = LSColor.ORANGE
    LIGHT_BLUE = LSColor.CYAN
    MAGENTA = LSColor.MAGENTA
    WHITE = LSColor.WHITE
    BLUE = LSColor.BLUE

# Approximate RGB references for LinnStrument colors.
# Used to map Ableton track.color to the nearest LinnStrument color.
LS_RGB = {
    LSColor.RED: (255, 0, 0),
    LSColor.YELLOW: (255, 255, 0),
    LSColor.GREEN: (0, 220, 0),
    LSColor.CYAN: (0, 220, 255),
    LSColor.BLUE: (0, 0, 255),
    LSColor.MAGENTA: (255, 0, 255),
    LSColor.WHITE: (255, 255, 255),
    LSColor.ORANGE: (255, 128, 0),
    LSColor.LIME: (128, 255, 0),
    LSColor.PINK: (255, 128, 200),
}

# Fallback only, if Ableton track.color is unavailable.
TRACK_CLIP_COLORS = [
    LSColor.BLUE,
    LSColor.MAGENTA,
    LSColor.CYAN,
    LSColor.GREEN,
    LSColor.PINK,
    LSColor.ORANGE,
    LSColor.LIME,
    LSColor.BLUE,
    LSColor.MAGENTA,
    LSColor.CYAN,
    LSColor.GREEN,
    LSColor.PINK,
    LSColor.ORANGE,
    LSColor.LIME,
]
