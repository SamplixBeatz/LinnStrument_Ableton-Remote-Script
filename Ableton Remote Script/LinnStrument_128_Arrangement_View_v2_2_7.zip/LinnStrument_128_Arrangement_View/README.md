# LinnStrument_128_Arrangement_View v1.0.6-refactor2b-128

Clean 128 build from stable 200 v1.0.3-refactor2b. Right block fixed at columns 14-16.
