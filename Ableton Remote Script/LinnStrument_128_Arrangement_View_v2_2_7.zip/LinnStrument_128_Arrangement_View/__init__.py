from __future__ import absolute_import, print_function, unicode_literals

from .linnstrument import LinnStrument

def create_instance(c_instance):
    return LinnStrument(c_instance)
