LinnStrument 128 Arrangement View v2.2.7

New Launch Quantization pads:
- D6: None, yellow
- D7: 1/16, yellow
- D8: 1 Bar, yellow

New Shift-only tempo pads:
- L6: Tempo +1 BPM, orange
- L7: Tempo -1 BPM, orange
- L8: Tap Tempo, orange

Shift pad:
- P8 on LinnStrument 128

Existing scrub, track-height zoom and Fold/Unfold functions remain unchanged.
Companion v2.2.6 remains compatible; no Companion update is required.
