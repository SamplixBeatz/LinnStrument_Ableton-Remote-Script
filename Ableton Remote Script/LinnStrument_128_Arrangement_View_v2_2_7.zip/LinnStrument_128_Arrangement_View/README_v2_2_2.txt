LinnStrument 128 Arrangement View v2.2.2

- N4: timeline scrub backward
- P4: timeline scrub forward
- Y expression controls scrub step from 0.25 to 4 beats
- Z expression remains disabled
