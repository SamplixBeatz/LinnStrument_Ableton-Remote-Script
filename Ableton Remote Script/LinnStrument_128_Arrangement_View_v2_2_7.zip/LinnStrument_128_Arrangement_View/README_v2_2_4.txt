LinnStrument 128 Arrangement View v2.2.4

- H6: increase active-track height while held
- J6: decrease active-track height while held
- H6/J6 are now blue
- N4/P4 scrub remains unchanged

Requires Companion v2.2.4 with track zoom support.
