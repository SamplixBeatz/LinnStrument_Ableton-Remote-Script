LinnStrument 128 Arrangement View v2.2.3

New vertical active-track zoom:
- H6: increase selected/active track height while held
- J6: decrease selected/active track height while held
- Both pads repeat in steps until Note Off
- Both pads are cyan

Existing N4/P4 timeline scrub remains unchanged.
Requires LinnStrument Companion v2.2.3.
