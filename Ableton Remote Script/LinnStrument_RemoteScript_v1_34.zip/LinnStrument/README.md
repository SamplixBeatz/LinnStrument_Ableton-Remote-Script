# LinnStrument Ableton Remote Script v1.34

Stable mainline version.

Goal:
- Start directly in Session Mode again.
- Avoid the LinnStrument freeze seen with the old v1.26 startup behavior.

Basis:
- Built from v1.33, which was the stable no-freeze version.
- The only intended behavioral change from v1.33 is startup mode:
  - v1.33 started in Note Mode.
  - v1.34 starts in Session Mode via the explicit `enter_session_mode()` path.

Retained:
- Unified LinnStrument 128 / 200 auto-detect.
- 7x13 Session clip matrix.
- Track Control row with Mute / Solo / Arm.
- Momentary Unified Copy Mode.
- Copy Clip / Copy Scene safety checks.
- Launch Quantization toggle.
- Tempo +/- 1 BPM via Shift + dynamic control column Pad 7/8.
- Arrangement/Session record context handling.
- Play/Stop protection.
- Mixer Mode behavior from the stable v1.26/v1.33 line.

Not included:
- Note AV Mode experiments.
- Soft Mute / Soft Solo / Soft Stop experiments.
- Arrangement clip duplicate/split/delete experiments.

Diagnostic background:
- v1.33 solved the project-change freeze by starting in Note Mode.
- Later diagnostics showed that explicitly entering Session Mode at startup did not reproduce the freeze.
- v1.34 uses that clean Session startup path.
